cd /root
quote=""

SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
SVR=$(uci get baking.server)
com=$(cat /proc/cpuinfo | grep "cpu model" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
rou=$(cat /proc/cpuinfo | grep "machine" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
boa=$(cat /proc/cpuinfo | grep "system type" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
nextrun=""
ttime=""
if [ -f /tmp/nextrun.txt ] ; then
  nextrun=$(cat /tmp/nextrun.txt)
fi
if [ -s testduration ] ; then
  ttime=$(cat testduration)
  if [ -s /tmp/bsw/u.txt ] ; then
    tdate=$(cat /tmp/bsw/u.txt | awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')
    ttime="$ttime @ $tdate" 
  fi
else
  ttime=""
fi
st=$(cat status)
mac=$(sh getmac.sh)
par=$(uci get baking.pcontrol 2&> /dev/null)
hos=$(uci get system.@system[0].hostname 2&> /dev/null) 
ip=$(uci -P /var/state get network.wan.ipaddr 2&> /dev/nul)
[ $? -eq 1 ] && { # si la conexión es ip fija, la wan ip no está en /var/state/network sino en /etc/config/network, entonces la sacamos de ahí.
    ip=$(uci get1 network.wan.ipaddr 2&> /dev/nul)
}
lio=$(uci -P /var/state get network.lan.ipaddr 2&> /dev/null)
if [ "$par" == "1" ] ; then
  par="Enabled"
else
  par="Disabled"
fi

ver=$(uci get system.version)
lastboot=$(cat lastboot| awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')

w=/www/index.html
rm /www/index.php &> /dev/null
d=$(date)
utime=$(uptime)
uname=$(uname -a)
vacation=""
vac1=$(uci get baking.ndw1 2&> /dev/null)
vac2=$(uci get baking.ndw2 2&> /dev/null)
if [ "$vac1" != "" ] ; then
  ddt=$(date +"%s")
  if [ $vac2 -gt $ddt ] ; then
    v1=$(echo $vac1 | awk '{ print strftime("%d/%m/%Y",$1+3600*3)}')
    v2=$(echo $vac2 | awk '{ print strftime("%d/%m/%Y",$1-3600*3)}')
    vacation="$v1 - $v2"
  fi
fi
working=$(uci get baking.horario 2&> /dev/null)
plan=$(uci get baking.plan 2&> /dev/null)
delay=$(uci get baking.delay 2&> /dev/null)
wf=$(uci get wireless.radio0.disabled 2&> /dev/null)
nwd=$(uci get baking.feriados 2&> /dev/nyll)
if [ $wf -eq 1 ] ; then
  wf="Disabled"
else
  wf="Enabled"
fi

if [ -e /tmp/config.sh ] ; then
  dt=$(cat lastconfig)
  conf="Yes [$dt]"
else
  conf="No"
  plan=""
  delay=""
  working=""
  state="Idle"
fi

x=$(uci show system | grep status | wc -l)     
if [ $x -eq 1 ] ; then                         
  xst=$(uci get system.status)                  
  if [ $xst -eq 1 ] ; then                      
    st="Router disabled on server"
    ttime="00:00:00"
  fi                                                             
fi        

echo "" > $w
echo '<html xmlns="http://www.w3.org/1999/xhtml">' >> $w
echo '<head>' >> $w
echo '<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />' >> $w
echo '<meta http-equiv="refresh" content="15" />' >> $w
echo '<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE" />' >> $w
echo '<META HTTP-EQUIV="EXPIRES" CONTENT="-1" />' >> $w
echo '<title>::Baking Sofware - bFirmware - 2011</title>' >> $w
echo '</head>' >> $w
echo '<a href="http://www.bsw.cl"><img src="logo.png" width="300" height="71" alt="BakingSoftware" /></a>' >> $w
echo "<center><big>" >> $w
echo "<table boder=1 cellspacing=0>" >> $w
echo "<tr><td>Router</td><td>$hos</td></tr>" >> $w
echo "<tr><td>MAC</td><td>$mac</td></tr>" >> $w
echo "<tr><td>Plan</td><td>$plan</td></tr>" >> $w
echo "<tr><td>Public IP</td><td>$ip</td></tr>" >> $w
echo "<tr><td>Local IP</td><td>$lio</td></tr>" >> $w
echo "<tr><td>Version</td><td>$ver</td></tr>" >> $w
echo "<tr><td>Board</td><td>$boa</td></tr>" >> $w
echo "<tr><td>Machine</td><td>$rou</td></tr>" >> $w
echo "<tr><td>Model</td><td>$com</td></tr>" >> $w
echo "<tr><td>WiFi</td><td>$wf</td></tr>" >> $w
echo "<tr><td>Parental Control</td><td>$par</td></tr>" >> $w
echo "<tr><td>Config File</td><td>$conf</td><tr>" >> $w
echo "<tr><td>Active Server</td><td>$SVR</td></tr>" >> $w
echo "<tr><td>Server 1</td><td>$SVR1</td></tr>" >> $w
echo "<tr><td>Server 2</td><td>$SVR2</td></tr>" >> $w
echo "<tr><td>Status</td><td>$st</td></tr>" >> $w
echo "<tr><td>Next run</td><td>$nextrun</td></tr>" >> $w
echo "<tr><td>Run every</td><td>$delay seconds</td></tr>" >> $w
echo "<tr><td>Working hours</td><td>$working</td></tr>" >> $w
echo "<tr><td>Vacations</td><td>$vacation</td></tr>" >> $w
echo "<tr><td>Hollidays</td><td>$nwd</td></tr>" >> $w
echo "<tr><td>Last update</td><td>$d</td></tr>" >> $w
echo "<tr><td>Test duration</td><td>$ttime</td></tr>" >> $w
echo "<tr><td>System </td><td>$uname</td></tr>" >> $w
echo "<tr><td>Uptime </td><td>$utime</td></tr>" >> $w
echo "<tr><td>Last Boot </td><td>$lastboot</td></tr>" >> $w
echo "</table>" >> $w
echo "</big></center>" >> $w
#q=$(cat quote.txt)
#echo "<br><br><center><big><italic>$q</italic></big></center>" >> $w
dd=$(date +"%s")
echo $dd > lastalive
