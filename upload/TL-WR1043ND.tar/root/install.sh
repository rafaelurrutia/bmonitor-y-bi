cd /tmp
mkdir install
cd install

wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/libcurl_7.38.0-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/curl_7.38.0-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/libpolarssl_1.3.8-2_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/packages/snmpd_5.4.4-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/packages/libnetsnmp_5.4.4-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/packages/snmp-utils_5.4.4-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/tc_3.15.0-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/kmod-sched-core_3.10.49-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/oldpackages/ifstat_1.1-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/oldpackages/bind-dig_9.9.4-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/oldpackages/fping_2.4b2_to-ipv6-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/libopenssl_1.0.1k-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/base/zlib_1.2.8-1_ar71xx.ipk
wget http://downloads.openwrt.org/barrier_breaker/14.07/ar71xx/generic/packages/oldpackages/bind-libs_9.9.4-1_ar71xx.ipk



opkg install bind-libs_9.9.4-1_ar71xx.ipk
opkg install libcurl_7.38.0-1_ar71xx.ipk
opkg install libpolarssl_1.3.8-2_ar71xx.ipk
opkg install libnetsnmp_5.4.4-1_ar71xx.ipk
opkg install tc_3.15.0-1_ar71xx.ipk
opkg install kmod-sched-core_3.10.49-1_ar71xx.ipk
opkg install libopenssl_1.0.1k-1_ar71xx.ipk
opkg install zlib_1.2.8-1_ar71xx.ipk

opkg install fping_2.4b2_to-ipv6-1_ar71xx.ipk
opkg install bind-dig_9.9.4-1_ar71xx.ipk
opkg install snmpd_5.4.4-1_ar71xx.ipk
opkg install ifstat_1.1-1_ar71xx.ipk
opkg install curl_7.38.0-1_ar71xx.ipk
opkg install snmp-utils_5.4.4-1_ar71xx.ipk


rm *.ipk

uci set system.bswkeepalive=0
uci set system.version=26.03.2013.e
uci set system.status=0
uci set system.lastupdate=2013-06-10_16-40-14
uci set system.bswslot=7

touch /etc/config/baking
uci set baking.server=bmonitor.baking.cl
uci set baking.server1=bmonitor.baking.cl
uci set baking.server2=bmonitor.baking.cl
uci set baking.pcontrol=0
uci set baking.delay=600
uci set baking.TZ=UTC+4
uci set baking.retry=3
uci set baking.maxretry=3
uci set baking.u=1421353628
uci set baking.TestRetry=1
uci set baking.horario=1-7,00:00-24:00
uci set baking.ISLAST=NO
uci set baking.ndw2=0



