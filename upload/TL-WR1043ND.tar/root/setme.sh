export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin

s=$(uci get $1)

uci set $1=$2
uci commit
if [ "$s" != "$2" ] ; then
  uci set system.@system[0].reboot=1
  uci commit
fi
  
