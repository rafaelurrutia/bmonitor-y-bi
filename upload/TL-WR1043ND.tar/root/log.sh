exit
d=$(date)
max=12
n=$(cat panic | wc -l)
if [ $n -ge $max ] ; then
  tail -$max panic > p.txt
  mv p.txt panic
fi
echo "$d $1" >> panic
