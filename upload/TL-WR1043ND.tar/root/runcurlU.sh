export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin

s=$1                                                                                                                                                                                                  
DOM=$(echo $s | awk 'BEGIN {FS=","}{srand();x=1+int(rand()*10 % NF);print $(x)}')

DOWNLOAD="http://$DOM/$2"
UPLOAD="http://$DOM/$3"
UPLOADFILE="@"$(uci get baking.kcore)
t=$(uci get baking.speedtest_$4_time_S)
N=$(uci get baking.speedtest_$4_sessions_S)
eth=$(netstat -nr | grep "^0.0.0.0" | awk '{print $8}')

rm -f /tmp/t*.txt
tout=$(uci get baking.maxretry)
  
for i in $(seq 1 $N)
do
  curl -w"%{speed_upload} %{time_total} %{time_starttransfer} %{size_upload}" --connect-timeout $tout --tcp-nodelay -s -m $t --form "upload=$UPLOADFILE" --form press=OK $UPLOAD | awk '{ print $1*8, $2, $3, $4}' > /tmp/t$i.txt &
  echo "curl  --connect-timeout $tout --tcp-nodelay -s -m $t --form upload=$UPLOADFILE --form press=OK $UPLOAD"
done

let tt=$t/2
ifstat -n -i $eth -b 1 $t > /tmp/o2.txt
bw=$(cat /tmp/o2.txt | awk '{print $2}' | sort -n | tail -$tt | awk 'BEGIN {I=0} {I=I+$1;} END {print int(I/(NR))}')
r=$(echo $bw | awk '{ print $1*1024 }')
# echo "upload $1:$r" >> /tmp/if.txt          
sleep 5
    
cnt=0
IN="0 0 0 0 0"
for i in $(seq 1 $N)
do
  if [ -e /tmp/t$i.txt ] ; then
    let cnt=$cnt+1
  fi
done
if [ $cnt -ne $N ] ; then
  echo "ERROR: Number of sessions less that expected $N<>$cnt"
  sh log.sh "ERROR: Number of sessions less that expected $N<>$cnt"
else  
  IN=$(cat /tmp/t*.txt | awk -v N="$N" 'BEGIN {a=0;b=0;c=0;d=0;e=0}{a+=$1;b+=($2-$3);c+=$3;d+=$4;if ($2!=$3) e+=$4/($2-$3)*8} END {if (b==0) b=1;printf("%d %d %d %d", d/(b/N)*8,b/N,d,e)}') 
fi 
rm /tmp/t*.txt    
mkdir /tmp/$5 &> /dev/null

echo $IN | awk '{ print "echo " $1 }' > /tmp/$5/$4bandwidthup.sh 
echo $IN | awk '{ print "echo " $2 }' > /tmp/$5/$4timeup.sh 
echo $IN | awk '{ print "echo " $3 }' > /tmp/$5/$4bytesup.sh 
echo $IN | awk '{ print "echo " $2 }' > /tmp/$5/$4bandwidthtimeup.sh 
echo $IN | awk '{ print "echo " $3 }' > /tmp/$5/$4bandwidthbyteup.sh 

echo "echo $r" > /tmp/$5/$4bandwidthupif.sh
echo "echo $DOM" > /tmp/$5/$4uploaddomain.sh
echo "echo $UPLOAD" > /tmp/$5/$4upload.sh
echo "echo $t" > /tmp/$5/$4uploadtime.sh
echo "echo $N" > /tmp/$5/$4uploadthreads.sh
echo "echo " $(date) > /tmp/$5/$4uploadtime.sh
 
#rm -f /tmp/t*.txt
echo "echo $r" > /tmp/$5/$4bandwidthbandwidthupif.sh
echo "echo $DOM" > /tmp/$5/$4bandwidthuploaddomain.sh
echo "echo $UPLOAD" > /tmp/$5/$4bandwidthupload.sh
echo "echo $t" > /tmp/$5/$4bandwidthuploadtime.sh
echo "echo $N" > /tmp/$5/$4bandwidthuploadthreads.sh
echo "echo $t" > /tmp/$5/$4bandwidthuploadtime.sh
 
  
