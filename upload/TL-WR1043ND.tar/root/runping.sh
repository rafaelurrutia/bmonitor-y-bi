export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin
sh log.sh "runping.sh: $1"
if [ $2 -eq 1 ] ; then                                                 
  uci set baking.TestRetry=1                                           
  uci commit
fi    

echo "Operational. Performing Ping $1" > status
SERVER=$(uci get baking.server)

R=$(uci get baking.retry)
sl=$(uci get baking.ping_$1_server)
URL=$(echo $sl | awk 'BEGIN {FS=","}{srand();x=int(rand()*10 % NF);print $(x)}')

Size=$(uci get baking.ping_$1_size)
Pings=$(uci get baking.ping_$1_count)
t=$(uci get baking.TestRetry)                         

mkdir /tmp/$t &> /dev/null
#fping -p 1000 -b $Size -C $Pings -s -q -u $URL 2> /tmp/$1fping.txt
rm -rf /tmp/$1fping.txt &> /dev/null
if3g=$(ifconfig -a | grep 3g-wan | wc -l)
if [ $if3g -eq 1 ] ; then
  wget -O /tmp/dummy http://$SERVER/linksys/openbsw.tar &> /dev/null
  rm /tmp/dummy
  fping -t 1000 -b $Size -C $Pings -s $URL 2>> /tmp/$1fping.txt 1> /tmp/$1fping.txt
else
  fping -t 10000 -b $Size -C $Pings -s $URL 2>> /tmp/$1fping.txt 1> /tmp/$1fping.txt
fi

cnt=$(grep "bytes," /tmp/$1fping.txt | wc -l)
if [ $cnt -ne 0 ] ; then
  grep "bytes," /tmp/$1fping.txt | awk -v p=$(grep "bytes," /tmp/$1fping.txt | awk 'BEGIN {p=0}{p=p+$6}END{print p/NR}') 'BEGIN {std=0}{std=std+($6-p)*($6-p)} END {print "echo ",sqrt(std/NR)}'  > /tmp/$t/$1pingstd.sh
  grep "bytes," /tmp/$1fping.txt | awk 'BEGIN {v=0;d=0;sum=0} {x=$6; if (NR>1)  {d=x-v;if (d<0) d=-d; sum=sum+d} v=x;} END {print "echo ",sum/NR}' > /tmp/$t/$1pingjitter.sh
  cp /tmp/$t/$1pingstd.sh  /tmp/$t/$1ping_std.sh
  cp /tmp/$t/$1pingjitter.sh /tmp/$t/$1ping_jitter.sh 
fi

cat /tmp/$1fping.txt | grep unreachable | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_unreachable.sh
cat /tmp/$1fping.txt | grep unreachable | awk '{ print "echo ",$1}' > /tmp/$t/$1pingunreachable.sh
cat /tmp/$1fping.txt | grep alive | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_alive.sh
cat /tmp/$1fping.txt | grep alive | awk '{ print "echo ",$1}' > /tmp/$t/$1pingalive.sh
cat /tmp/$1fping.txt | grep timeouts | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_timeouts.sh
cat /tmp/$1fping.txt | grep timeouts | awk '{ print "echo ",$1}' > /tmp/$t/$1pingtimeouts.sh
cat /tmp/$1fping.txt | grep "ICMP Echos sent" | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_ICMP_Echos_sent.sh
cat /tmp/$1fping.txt | grep "ICMP Echos sent" | awk '{ print "echo ",$1}' > /tmp/$t/$1pingICMP_Echos_sent.sh
cat /tmp/$1fping.txt | grep "ICMP Echo Replies received" | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_ICMP_Echo_Replies_received.sh
cat /tmp/$1fping.txt | grep "ICMP Echo Replies received" | awk '{ print "echo ",$1}' > /tmp/$t/$1pingICMP_Echo_Replies_received.sh
cat /tmp/$1fping.txt | grep "min round" | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_min.sh
cat /tmp/$1fping.txt | grep "min round" | awk '{ print "echo ",$1}' > /tmp/$t/$1pingmin.sh
cat /tmp/$1fping.txt | grep "avg round" | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_avg.sh
cat /tmp/$1fping.txt | grep "avg round" | awk '{ print "echo ",$1}' > /tmp/$t/$1pingavg.sh
cat /tmp/$1fping.txt | grep "max round" | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_max.sh
cat /tmp/$1fping.txt | grep "max round" | awk '{ print "echo ",$1}' > /tmp/$t/$1pingmax.sh
cat /tmp/$1fping.txt | grep "elapsed" | awk '{ print "echo ",$1}' > /tmp/$t/$1ping_elapsed.sh
cat /tmp/$1fping.txt | grep "elapsed" | awk '{ print "echo ",$1}' > /tmp/$t/$1pingelapsed.sh
echo "echo " $(date) > /tmp/$t/$1ping_date.sh
echo "echo " $(date) > /tmp/$t/$1pingdate.sh
echo "echo $URL" > /tmp/$t/$1ping_url.sh
echo "echo $URL" > /tmp/$t/$1pingurl.sh

l1=$(sh /tmp/$t/$1ping_ICMP_Echos_sent.sh)
l2=$(sh /tmp/$t/$1ping_ICMP_Echo_Replies_received.sh)
lost=$(echo $l1 $l2 | awk '{print 100-$2/$1*100}')
echo "echo $lost" > /tmp/$t/$1ping_lost.sh
echo "echo $lost" > /tmp/$t/$1pinglost.sh

val=$(sh /tmp/$t/$1ping_ICMP_Echo_Replies_received.sh | awk '{ print $1 }')
min=$(uci get baking.ping_$1_latencia | awk '{ print $1}')
if [ $val -ge $min ] ; then
  cp /tmp/$t/* /tmp/bsw
  echo "echo 1">/tmp/bsw/$1ping_OK.sh
  echo "echo 1">/tmp/bsw/$1pingOK.sh
  echo "Ping $1 Try $t [$val] OK"
  rm -rf /tmp/1 &> /dev/null
  rm -rf /tmp/2 &> /dev/null
  rm -rf /tmp/3 &> /dev/null
else
  if [ $t -eq $R ] ; then                     
    val1=$(sh /tmp/1/$1ping_avg.sh | awk '{ print $1*1000}')
    val2=$(sh /tmp/2/$1ping_avg.sh | awk '{ print $1*1000}')
    val3=$(sh /tmp/3/$1ping_avg.sh | awk '{ print $1*1000}')
    if [ $val1 -le $val2 ] ; then
      if [ $val1 -le $val3 ] ; then
        cp /tmp/1/* /tmp/bsw
       	echo "Ping $1 Try $t [$val] BEST 1=>[$val1]"
      fi
    fi
    if [ $val2 -le $val1 ] ; then
      if [ $val2 -le $val3 ] ; then
        cp /tmp/2/* /tmp/bsw
       	echo "Ping $1 Try $t [$val] BEST 2=>[$val2]"
      fi
    fi
    if [ $val3 -le $val1 ] ; then
      if [ $val3 -le $val2 ] ; then
        cp /tmp/3/* /tmp/bsw
       	echo "Ping $1 Try $t [$val] BEST 3=>[$val3]"
      fi
    fi
    echo "echo 0">/tmp/bsw/$1ping_OK.sh
    echo "echo 0">/tmp/bsw/$1pingOK.sh
    rm -rf /tmp/1 &> /dev/null
    rm -rf /tmp/2 &> /dev/null
    rm -rf /tmp/3 &> /dev/null
  else
    echo "PING $1 Try $t [$val]"
    let t=$t+1     
    uci set baking.TestRetry=$t
    uci commit     
    sh runping.sh $1 2
  fi
fi
    
