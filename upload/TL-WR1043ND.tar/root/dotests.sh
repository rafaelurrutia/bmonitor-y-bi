export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin

echo ">Starting test"
sh log.sh "dotests.sh: Tests Begin"
sh checkinternet.sh

rd=$(type rdate  | grep "not found" | wc -l)
if [ $rd == 0 ] ; then
  /usr/sbin/rdate -s nist1.symmetricom.com
fi

fs=$(df -k /tmp | grep -v Filesystem | awk '{if ($4>1200) print 1; else print 0;}')

if [ $fs -eq 0 ] ; then
  sh log.sh "Too many test pending to post. Aborting this test"
  exit
fi


x=$(uci show baking | grep feriados | wc -l)
if [ $x -eq 1 ] ; then
  clock="NODATES"
  clock=$(uci get baking.feriados)
  go=0
  if [ "$clock" != "" ] ; then
    d=$(date +"%d/%m")
    go=$(echo $clock $d | awk '{print match($1,$2)}')
  fi  

  if [ $go -ne 0 ] ; then
    echo "No working day. Exit"
    exit
  fi
fi

x=$(uci show system | grep status | wc -l)
if [ $x -eq 1 ] ; then
  st=$(uci get system.status)
  if [ $st -eq 1 ] ; then
    echo "Router disabled on server. Exit"
    exit
  fi
fi
OK1=$(sh cdate.sh $(uci get baking.horario))
if [ "$OK1" == "NO" ] ; then
  echo "WARNING. YOU ARE RUNNING THE TEST ON NON OPERATIONAL HOUR"
fi

echo "Operational. Preparing for Test" > status
u=$(date +"%s")
echo $u > /tmp/bsw/u.txt
uci set baking.u=$u
uci commit
rm /tmp/bsw/NACband* >& /dev/null
rm /tmp/bsw/NACbytes* >& /dev/null
rm /tmp/bsw/NACdomain.sh >& /dev/null
rm /tmp/bsw/NACdownload* >& /dev/null
rm /tmp/bsw/NACtime* >& /dev/null
rm /tmp/bsw/NACupload* >& /dev/null
d=$(uci get baking.speedtest_NAC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download NAC speedtest"
  sh dospeedtestD.sh NAC 1 0
  c=$(sh /tmp/bsw/NACbandwidthdownOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACbandwidthdown.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthdown.sh
    m=$(sh /tmp/bsw/NACbandwidthdownif.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthdownif.sh
    echo "echo -$m" > /tmp/bsw/NACibandwidthbandwidthdownif.sh
    m=$(sh /tmp/bsw/NACbytesdown.sh)
    echo "echo -$m" > /tmp/bsw/NACbytesdown.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthbytedown.sh
    m=$(sh /tmp/bsw/NACtimedown.sh)
    echo "echo -$m" > /tmp/bsw/NACtimedown.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthtimedown.sh
    m=$(sh /tmp/bsw/NACdownloadtime.sh)
    echo "echo -$m" > /tmp/bsw/NACdownloadtime.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthdownloadtime.sh
  fi
  echo ">Running upload NAC speedtest"
  sh dospeedtestU.sh NAC 1 0
  c=$(sh /tmp/bsw/NACbandwidthupOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACbandwidthup.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthup.sh
    m=$(sh /tmp/bsw/NACbandwidthupif.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthupif.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthbandwidthupif.sh
    m=$(sh /tmp/bsw/NACbytesup.sh)
    echo "echo -$m" > /tmp/bsw/NACbytesup.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthbyteup.sh
    m=$(sh /tmp/bsw/NACtimeup.sh)
    echo "echo -$m" > /tmp/bsw/NACtimeup.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthtimeup.sh
    m=$(sh /tmp/bsw/NACuploadtime.sh)
    echo "echo -$m" > /tmp/bsw/NACuploadtime.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthuploadtime.sh
  fi
fi
rm /tmp/bsw/LOCband* >& /dev/null
rm /tmp/bsw/LOCbytes* >& /dev/null
rm /tmp/bsw/LOCdomain.sh >& /dev/null
rm /tmp/bsw/LOCdownload* >& /dev/null
rm /tmp/bsw/LOCtime* >& /dev/null
rm /tmp/bsw/LOCupload* >& /dev/null
d=$(uci get baking.speedtest_LOC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download LOC speedtest"
  sh dospeedtestD.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCbandwidthdownOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCbandwidthdown.sh)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdown.sh
    m=$(sh /tmp/bsw/LOCbandwidthdownif.sh)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdownif.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbandwidthdownif.sh
    m=$(sh /tmp/bsw/LOCbytesdown.sh)
    echo "echo -$m" > /tmp/bsw/LOCbytesdown.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbytedown.sh
    m=$(sh /tmp/bsw/LOCtimedown.sh)
    echo "echo -$m" > /tmp/bsw/LOCtimedown.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthtimedown.sh
    m=$(sh /tmp/bsw/LOCdownloadtime.sh)
    echo "echo -$m" > /tmp/bsw/LOCdownloadtime.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdownloadtime.sh
  fi
  echo ">Running upload LOC speedtest"
  sh dospeedtestU.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCbandwidthupOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCbandwidthup.sh)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthup.sh
    m=$(sh /tmp/bsw/LOCbandwidthupif.sh)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthupif.sh
    m=$(sh /tmp/bsw/LOCbytesup.sh)
    echo "echo -$m" > /tmp/bsw/LOCbytesup.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbyteup.sh
    m=$(sh /tmp/bsw/LOCtimeup.sh)
    echo "echo -$m" > /tmp/bsw/LOCtimeup.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthtimeup.sh
    m=$(sh /tmp/bsw/LOCuploadtime.sh)
    echo "echo -$m" > /tmp/bsw/LOCuploadtime.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthuploadtime.sh
  fi
fi
rm /tmp/bsw/INTband* >& /dev/null
rm /tmp/bsw/INTbytes* >& /dev/null
rm /tmp/bsw/INTdomain.sh >& /dev/null
rm /tmp/bsw/INTdownload* >& /dev/null
rm /tmp/bsw/INTtime* >& /dev/null
rm /tmp/bsw/INTupload* >& /dev/null
d=$(uci get baking.speedtest_INT_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download INT speedtest"
  sh dospeedtestD.sh INT 1 0
  c=$(sh /tmp/bsw/INTbandwidthdownOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTbandwidthdown.sh)
    echo "echo -$m" > /tmp/bsw/INTbandwidthdown.sh
    m=$(sh /tmp/bsw/INTbandwidthdownif.sh)
    echo "echo -$m" > /tmp/bsw/INTbandwidthdownif.sh
    m=$(sh /tmp/bsw/INTbytesdown.sh)
    echo "echo -$m" > /tmp/bsw/INTbytesdown.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthbytedown.sh
    m=$(sh /tmp/bsw/INTtimedown.sh)
    echo "echo -$m" > /tmp/bsw/INTtimedown.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthtimedown.sh
    m=$(sh /tmp/bsw/INTdownloadtime.sh)
    echo "echo -$m" > /tmp/bsw/INTdownloadtime.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthuploadtime.sh
  fi
  echo ">Running upload INT speedtest"
  sh dospeedtestU.sh INT 1 0
  c=$(sh /tmp/bsw/INTbandwidthupOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTbandwidthup.sh)
    echo "echo -$m" > /tmp/bsw/INTbandwidthup.sh
    m=$(sh /tmp/bsw/INTbandwidthupif.sh)
    echo "echo -$m" > /tmp/bsw/INTbandwidthupif.sh
    m=$(sh /tmp/bsw/INTbytesup.sh)
    echo "echo -$m" > /tmp/bsw/INTbytesup.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthbyteup.sh
    m=$(sh /tmp/bsw/INTtimeup.sh)
    echo "echo -$m" > /tmp/bsw/INTtimeup.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthtimeup.sh
    m=$(sh /tmp/bsw/INTuploadtime.sh)
    echo "echo -$m" > /tmp/bsw/INTuploadtime.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthuploadtime.sh
  fi
fi
rm /tmp/bsw/NACping* >& /dev/null
d=$(uci get baking.ping_NAC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping NAC"
  sh runping.sh NAC 1 0
  c=$(sh /tmp/bsw/NACping_OK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACping_avg.sh)
    echo "echo -$m" > /tmp/bsw/NACping_avg.sh
    echo "echo -$m" > /tmp/bsw/NACpingavg.sh
    m=$(sh /tmp/bsw/NACping_avg.sh)
    echo "echo -$m" > /tmp/bsw/NACping_max.sh
    echo "echo -$m" > /tmp/bsw/NACpingmax.sh
    m=$(sh /tmp/bsw/NACping_avg.sh)
    echo "echo -$m" > /tmp/bsw/NACping_min.sh
    echo "echo -$m" > /tmp/bsw/NACpingmin.sh
    m=$(sh /tmp/bsw/NACping_std.sh)
    echo "echo -$m" > /tmp/bsw/NACping_std.sh
    echo "echo -$m" > /tmp/bsw/NACpingstd.sh
    m=$(sh /tmp/bsw/NACping_timeouts.sh)
    echo "echo -$m" > /tmp/bsw/NACping_timeouts.sh
    echo "echo -$m" > /tmp/bsw/NACpingtimeouts.sh
    m=$(sh /tmp/bsw/NACping_ICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/NACping_ICMP_Echo_Replies_received.sh
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/NACping_ICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/NACping_ICMP_Echos_sent.sh
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/NACping_alive.sh)
    echo "echo -$m" > /tmp/bsw/NACping_alive.sh
    echo "echo -$m" > /tmp/bsw/NACpingalive.sh
    m=$(sh /tmp/bsw/NACping_lost.sh)
    echo "echo -$m" > /tmp/bsw/NACping_lost.sh
    echo "echo -$m" > /tmp/bsw/NACpinglost.sh
    m=$(sh /tmp/bsw/NACping_jitter.sh)
    echo "echo -$m" > /tmp/bsw/NACping_jitter.sh
    echo "echo -$m" > /tmp/bsw/NACpingjitter.sh
  fi
fi
rm /tmp/bsw/INTping* >& /dev/null
d=$(uci get baking.ping_INT_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping INT"
  sh runping.sh INT 1 0
  c=$(sh /tmp/bsw/INTping_OK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTping_avg.sh)
    echo "echo -$m" > /tmp/bsw/INTping_avg.sh
    echo "echo -$m" > /tmp/bsw/INTpingavg.sh
    m=$(sh /tmp/bsw/INTping_avg.sh)
    echo "echo -$m" > /tmp/bsw/INTping_max.sh
    echo "echo -$m" > /tmp/bsw/INTpingmax.sh
    m=$(sh /tmp/bsw/INTping_avg.sh)
    echo "echo -$m" > /tmp/bsw/INTping_min.sh
    echo "echo -$m" > /tmp/bsw/INTpingmin.sh
    m=$(sh /tmp/bsw/INTping_std.sh)
    echo "echo -$m" > /tmp/bsw/INTping_std.sh
    echo "echo -$m" > /tmp/bsw/INTpingstd.sh
    m=$(sh /tmp/bsw/INTping_timeouts.sh)
    echo "echo -$m" > /tmp/bsw/INTping_timeouts.sh
    echo "echo -$m" > /tmp/bsw/INTpingtimeouts.sh
    m=$(sh /tmp/bsw/INTping_ICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/INTping_ICMP_Echo_Replies_received.sh
    echo "echo -$m" > /tmp/bsw/INTpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/INTping_ICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/INTping_ICMP_Echos_sent.sh
    echo "echo -$m" > /tmp/bsw/INTpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/INTping_alive.sh)
    echo "echo -$m" > /tmp/bsw/INTping_alive.sh
    echo "echo -$m" > /tmp/bsw/INTpingalive.sh
    m=$(sh /tmp/bsw/INTping_lost.sh)
    echo "echo -$m" > /tmp/bsw/INTping_lost.sh
    echo "echo -$m" > /tmp/bsw/INTpinglost.sh
    m=$(sh /tmp/bsw/INTping_jitter.sh)
    echo "echo -$m" > /tmp/bsw/INTping_jitter.sh
    echo "echo -$m" > /tmp/bsw/INTpingjitter.sh
  fi
fi
rm /tmp/bsw/LOCping* >& /dev/null
d=$(uci get baking.ping_LOC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping LOC"
  sh runping.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCping_OK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCping_avg.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_avg.sh
    echo "echo -$m" > /tmp/bsw/LOCpingavg.sh
    m=$(sh /tmp/bsw/LOCping_avg.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_max.sh
    echo "echo -$m" > /tmp/bsw/LOCpingmax.sh
    m=$(sh /tmp/bsw/LOCping_avg.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_min.sh
    echo "echo -$m" > /tmp/bsw/LOCpingmin.sh
    m=$(sh /tmp/bsw/LOCping_std.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_std.sh
    echo "echo -$m" > /tmp/bsw/LOCpingstd.sh
    m=$(sh /tmp/bsw/LOCping_timeouts.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_timeouts.sh
    echo "echo -$m" > /tmp/bsw/LOCpingtimeouts.sh
    m=$(sh /tmp/bsw/LOCping_ICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_ICMP_Echo_Replies_received.sh
    echo "echo -$m" > /tmp/bsw/LOCpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/LOCping_ICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_ICMP_Echos_sent.sh
    echo "echo -$m" > /tmp/bsw/LOCpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/LOCping_alive.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_alive.sh
    echo "echo -$m" > /tmp/bsw/LOCpingalive.sh
    m=$(sh /tmp/bsw/LOCping_lost.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_lost.sh
    echo "echo -$m" > /tmp/bsw/LOCApinglost.sh
    m=$(sh /tmp/bsw/LOCping_jitter.sh)
    echo "echo -$m" > /tmp/bsw/LOCping_jitter.sh
    echo "echo -$m" > /tmp/bsw/LOCpingjitter.sh
  fi
fi
rm /tmp/bsw/ip* >& /dev/null
d=$(uci get baking.renew)
if [ $d -ne 0 ] ; then
  echo ">Running RENEW"
  sh runrenew.sh 
  c=$(sh /tmp/bsw/ip_OK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/ip_renew.sh)
    echo "echo -$m" > /tmp/bsw/ip_renew.sh
    echo "echo -$m" > /tmp/bsw/IPloginrenew.sh
    m=$(sh /tmp/bsw/ip_renew_status.sh)
    echo "echo -$m" > /tmp/bsw/ip_renew_status.sh
    echo "echo -$m" > /tmp/bsw/IPloginrenew_status.sh
  fi
fi
cp /tmp/bsw/* /root/bsw >& /dev/null
sleep 10
sh trap.sh
sh postvalue.sh

sh log.sh "dotests.sh: Test completed"
echo "" > /tmp/nextrun.txt
