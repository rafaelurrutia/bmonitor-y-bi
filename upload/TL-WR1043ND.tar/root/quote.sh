echo ">Generating new dayly quote"
cd /root

quote=$(wget -t5 -q -O - http://www.quotationspage.com/data/1mqotd.js | grep "tqpQuote" | awk '{ print substr($0,42)}' | awk '{ print substr($0,1,length($0)-8)}' )
echo $quote > quote.txt
