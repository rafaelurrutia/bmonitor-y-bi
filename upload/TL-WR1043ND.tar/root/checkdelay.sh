echo ">CHECKING DELAY CHANGE"
cd /root

v=$(uci get baking.delay)

if [ "$v" != "$1" ] ; then
  uci set baking.delay=$1
  t=$1
  if [ "$t" != "0" ] ; then 
    r=$(echo $t | awk  '{ srand();x=int(rand()*100 % ($1/60)); print x; }')
    uci set system.bswslot=$r
  else
    uci set system.bswslot=0
  fi
  uci commit
fi
