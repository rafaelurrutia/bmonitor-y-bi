export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin:/root

echo ">Starting test"
sh log.sh "dotests.sh: Tests Begin"
sh checkinternet.sh

ntp=$(type ntpdate 2>/dev/null | wc -l)
if [ $ntp -eq 1 ] ; then
  ntpdate -s pool.ntp.org 
else 
  rdate=$(type rdate | awk '{ print $3}')
  $rdate -s nist1.symmetricom.com
fi

fs=$(df -k /tmp | grep -v Filesystem | awk '{if ($4>1200) print 1; else print 0;}')

if [ $fs -eq 0 ] ; then
  sh log.sh "Too many test pending to post. Aborting this test"
  exit
fi


x=$(uci show baking | grep feriados | wc -l)
if [ $x -eq 1 ] ; then
  clock="NODATES"
  clock=$(uci get baking.feriados)
  go=0
  if [ "$clock" != "" ] ; then
    d=$(date +"%d/%m")
    go=$(echo $clock $d | awk '{print match($1,$2)}')
  fi  

  if [ $go -ne 0 ] ; then
    echo "No working day. Exit"
    exit
  fi
fi

x=$(uci show system | grep status | wc -l)
if [ $x -eq 1 ] ; then
  st=$(uci get system.status)
  if [ $st -eq 1 ] ; then
    echo "Router disabled on server. Exit"
    exit
  fi
fi
OK1=$(sh cdate.sh $(uci get baking.horario))
if [ "$OK1" == "NO" ] ; then
  echo "WARNING. YOU ARE RUNNING THE TEST ON NON OPERATIONAL HOUR"
fi

echo "Operational. Preparing for Test" > status

u=$(date +"%s")
echo $u > /tmp/bsw/u.txt
uci set baking.u=$u
uci commit
rm /tmp/bsw/NACband* >& /dev/null
rm /tmp/bsw/NACbytes* >& /dev/null
rm /tmp/bsw/NACdomain.sh >& /dev/null
rm /tmp/bsw/NACdownload* >& /dev/null
rm /tmp/bsw/NACtime* >& /dev/null
rm /tmp/bsw/NACupload* >& /dev/null
d=$(uci get baking.speedtest_NAC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download NAC speedtest"
  sh dospeedtestD.sh NAC 1 0
  c=$(sh /tmp/bsw/NACbandwidthdownOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACbandwidthdown.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthdown.sh
    m=$(sh /tmp/bsw/NACbandwidthdownif.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthdownif.sh
    m=$(sh /tmp/bsw/NACbytedown.sh)
    echo "echo -$m" > /tmp/bsw/NACbytedown.sh
    m=$(sh /tmp/bsw/NACtimedown.sh)
    echo "echo -$m" > /tmp/bsw/NACtimedown.sh
  fi
  echo ">Running upload NAC speedtest"
  sh dospeedtestU.sh NAC 1 0
  c=$(sh /tmp/bsw/NACbandwidthupOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACbandwidthup.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthup.sh
    m=$(sh /tmp/bsw/NACbandwidthupif.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthupif.sh
    m=$(sh /tmp/bsw/NACbyteup.sh)
    echo "echo -$m" > /tmp/bsw/NACbyteup.sh
    m=$(sh /tmp/bsw/NACtimeup.sh)
    echo "echo -$m" > /tmp/bsw/NACtimeup.sh
  fi
fi
rm /tmp/bsw/LOCband* >& /dev/null
rm /tmp/bsw/LOCbytes* >& /dev/null
rm /tmp/bsw/LOCdomain.sh >& /dev/null
rm /tmp/bsw/LOCdownload* >& /dev/null
rm /tmp/bsw/LOCtime* >& /dev/null
rm /tmp/bsw/LOCupload* >& /dev/null
d=$(uci get baking.speedtest_LOC_server 2> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download LOC speedtest"
  sh dospeedtestD.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCbandwidthdownOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCbandwidthdown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdown.sh
    m=$(sh /tmp/bsw/LOCbandwidthdownif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdownif.sh
    m=$(sh /tmp/bsw/LOCbytedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbytedown.sh
    m=$(sh /tmp/bsw/LOCtimedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCtimedown.sh
  fi
  echo ">Running upload LOC speedtest"
  sh dospeedtestU.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCbandwidthupOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCbandwidthup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthup.sh
    m=$(sh /tmp/bsw/LOCbandwidthupif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthupif.sh
    m=$(sh /tmp/bsw/LOCbyteup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbyteup.sh
    m=$(sh /tmp/bsw/LOCtimeup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCtimeup.sh
  fi
fi
rm /tmp/bsw/INTband* >& /dev/null
rm /tmp/bsw/INTbytes* >& /dev/null
rm /tmp/bsw/INTdomain.sh >& /dev/null
rm /tmp/bsw/INTdownload* >& /dev/null
rm /tmp/bsw/INTtime* >& /dev/null
rm /tmp/bsw/INTupload* >& /dev/null
d=$(uci get baking.speedtest_INT_server 2> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download INT speedtest"
  sh dospeedtestD.sh INT 1 0
  c=$(sh /tmp/bsw/INTbandwidthdownOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTbandwidthdown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthdown.sh
    m=$(sh /tmp/bsw/INTbandwidthdownif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthdownif.sh
    m=$(sh /tmp/bsw/INTbytedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbytedown.sh
    m=$(sh /tmp/bsw/INTtimedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTtimedown.sh
  fi
  echo ">Running upload INT speedtest"
  sh dospeedtestU.sh INT 1 0
  c=$(sh /tmp/bsw/INTbandwidthupOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTbandwidthup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthup.sh
    m=$(sh /tmp/bsw/INTbandwidthupif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthupif.sh
    m=$(sh /tmp/bsw/INTbyteup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbyteup.sh
    m=$(sh /tmp/bsw/INTtimeup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTtimeup.sh
  fi
fi
rm /tmp/bsw/NACping* >& /dev/null
d=$(uci get baking.ping_NAC_server 2> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping NAC"
  sh runping.sh NAC 1 0
  c=$(sh /tmp/bsw/NACpingOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACpingavg.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingavg.sh
    m=$(sh /tmp/bsw/NACpingmsx.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingmax.sh
    m=$(sh /tmp/bsw/NACpingmin.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingmin.sh
    m=$(sh /tmp/bsw/NACpingstd.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingstd.sh
    m=$(sh /tmp/bsw/NACpingtimeouts.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingtimeouts.sh
    m=$(sh /tmp/bsw/NACpingICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/NACpingICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/NACpingalive.sh)
    echo "echo -$m" > /tmp/bsw/NACpingalive.sh
  fi
fi
rm /tmp/bsw/INTping* >& /dev/null
d=$(uci get baking.ping_INT_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping INT"
  sh runping.sh INT 1 0
  c=$(sh /tmp/bsw/INTpingOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTpingavg.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingavg.sh
    m=$(sh /tmp/bsw/INTpingmax.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingmax.sh
    m=$(sh /tmp/bsw/INTpingmin.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingmin.sh
    m=$(sh /tmp/bsw/INTpingstd.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingstd.sh
    m=$(sh /tmp/bsw/INTpingtimeouts.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingtimeouts.sh
    m=$(sh /tmp/bsw/INTpingICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/INTpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/INTpingICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/INTpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/INTpingalive.sh)
    echo "echo -$m" > /tmp/bsw/INTpingalive.sh
  fi
fi
rm /tmp/bsw/LOCping* >& /dev/null
d=$(uci get baking.pingLOC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping LOC"
  sh runping.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCpingOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCpingavg.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingavg.sh
    m=$(sh /tmp/bsw/NACpingmax.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingmax.sh
    m=$(sh /tmp/bsw/NACpingmin.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingmin.sh
    m=$(sh /tmp/bsw/NACpingstd.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingstd.sh
    m=$(sh /tmp/bsw/NACpingtimeouts.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingtimeouts.sh
    m=$(sh /tmp/bsw/NACpingICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/NACpingICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/NACpingalive.sh)
    echo "echo -$m" > /tmp/bsw/NACpingalive.sh
  fi
fi
rm /tmp/bsw/ip* >& /dev/null
d=$(uci get baking.renew)
if [ $d -ne 0 ] ; then
  echo ">Running RENEW"
  sh runrenew.sh 
  c=$(sh /tmp/bsw/iploginOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/iploginrenew.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/iploginrenuew.sh
    m=$(sh /tmp/bsw/iploginrenew_status.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/iploginrenuew_status.sh
  fi
fi
cp /tmp/bsw/* /root/bsw >& /dev/null
sleep 10
sh trap.sh
sh postvalue.sh

sh log.sh "dotests.sh: Test completed"
echo "" > /tmp/nextrun.txt

