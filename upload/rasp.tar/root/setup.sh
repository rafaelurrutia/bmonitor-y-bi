yum update
yum install net-tools fping httpd.armv6hl php ifstat.armv6hl net-snmp.armv6h net-snmp-utils.armv6hl net-snmp-sysvinit.armv6hl

