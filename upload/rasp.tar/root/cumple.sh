PATH=$PATH:/root
# $1 INT/NAC/LOC
# $2 D/U
# $3 t

if [ "$2" == "D" ] ; then
  dirOK="downOK"
  dir="down"
else
  dirOK="upOK"
  dir="up"
fi
tran=$(uci get baking.$1_$2)                                                          
let tran=$tran*1024/8*2         
if [ -s /tmp/$3/$1bandwidthbyte$dir.sh ] ; then
  bytes=$(sh /tmp/$3/$1bandwidthbyte$dir.sh)        
  if [ $bytes -ge $tran ] ; then            
    echo "echo 1">/tmp/$3/$1bandwidth$dirOK.sh
    #echo "Data transfer passed"
    #echo "Speedtest $1 $DIR Try $3 Passed. [$bytes bytes >= $tran bytes]"
  else                                         
    echo "echo 0">/tmp/$3/$1bandwidth$dirOK.sh
    #echo "Data transfer fail"
    #echo "Speedtest $1 $DIR Tray $3 Fail. [$bytes bytes < $tran bytes]"
  fi
else
  echo "Error: File /tmp/$3/$1bandwidthbyte$dir.sh do not exist"
fi                       

