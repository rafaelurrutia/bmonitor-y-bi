PATH=$PATH:/root
SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
SVR=$SVR1
clock=$(cat lastalive)
#eth=$(netstat -nr | grep "^0.0.0.0" | awk '{print $8}')
#mac=$(ifconfig $eth | head -1 | awk '{ print $5 '} | awk '{gsub(" ","_"); print $1}')
mac=$(sh getmac.sh)
r=""
while [ "$r" == "" ] ; do
  rm /tmp/poweroff >& /dev/null
  wget -q -T 2 -O /tmp/poweroff "http://$SVR1/linksys/poweroff.php?clock=$clock&mac=$mac" &> /dev/null
  g=$(cat /tmp/poweroff | grep END | wc -l)
  if [ $g -eq 0 ] ; then
    rm /tmp/poweroff >& /dev/null
  fi
  if [ -s /tmp/poweroff ] ; then
    SVR=$SVR1
    uci set baking.server=$SVR
    uci commit
  else
    wget -q -T 2 -O /tmp/poweroff "http://$SVR2/linksys/poweroff.php?clock=$clock&mac=$mac" &>/dev/null
    g=$(cat /tmp/poweroff | grep END | wc -l)
    if [ $g -eq 0 ] ; then
      rm /tmp/poweroff >& /dev/null
    fi
    if [ -s /tmp/poweroff ] ; then
      SVR=$SVR2
      uci set baking.server=$SVR
      uci commit
    fi
  fi
  r=$(cat /tmp/poweroff | grep END | wc -l) 
done


