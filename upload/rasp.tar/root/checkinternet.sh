PATH=$PATH:/root

c=0
cnt=0
sh log.sh "checkinternet.sh"
echo ">Checking Internet"
while [ $c -eq 0 ] ;
do
  if3g=$(ifconfig -a | grep 3g-wan | wc -l)
  if [ $if3g -eq 1 ] ; then
    wget --timeout=5 -O /tmp/dummynet http://www.google.cl  >& /dev/null
    rm /tmp/dummynet &> /dev/null
  fi 
  c=$(fping -t1000 -s -c 2 -r 1 www.yahoo.com 2>&1 | grep "2 ICMP Echo Replies" | wc -l)
  if [ $c -eq 0 ] ; then            
    sleep 5
    c=$(fping -t1000 -s -c 2 -r 1 www.chile.cl 2>&1 | grep "2 ICMP Echo Replies" | wc -l)
  fi
  if [ $c -eq 0 ] ; then            
    sleep 5
    c=$(fping -t1000 -s -c 2 -r 1 www.google.com 2>&1 | grep "2 ICMP Echo Replies" | wc -l)
  fi
  if [ $c -eq 0 ] ; then            
    sleep 5
    c=$(fping -t1000 -s -c 2 -r 1 www.uchile.cl 2>&1 | grep "2 ICMP Echo Replies" | wc -l)
  fi
  if [ $c -eq 0 ] ; then            
    sh log.sh "checkinternet.sh: Network error"                                   
    if [ $if3g -eq 1 ] ; then
      sh log.sh "checkinternet.sh: Reset usb"                                   
      gcom -s /etc/gcom/GPRSdown.gcom
      echo 0 > /sys/devices/platform/ar71xx-ehci/usb1/1-1/authorized
      sleep 20
      echo 1 > /sys/devices/platform/ar71xx-ehci/usb1/1-1/authorized
      sleep 20
    fi 
    sh log.sh "checkinternet.sh: Network restart"                                   
    /etc/init.d/network restart     
    let cnt=$cnt+1
    sleep 10
    pc=$(uci get baking.pcontrol 2&> /dev/null)
    if [ "$pc" == "1" ] ; then
      sh pcontrol.sh
    fi
    if [ $cnt -ge 3 ] ; then
      sh log.sh "checkinternet.sh: usb_modeswitch"                                   
      usb_modeswitch -I -W -H -R -c 1446.cfg
      sleep 20
      usb_modeswitch -I -W -H -R -c 1436.cfg
      sleep 20
      if [ "$pc" == "1" ] ; then                                                                            
        sh pcontrol.sh                                                                                        
      fi      
#      /etc/init.d/network restart 
#      rm /root/bsw/* >& /dev/null
#      cp /tmp/bsw/* /root/bsw >& /dev/null
      cnt=0
    fi                        
  else
    cnt=0
  fi                                
done
sh log.sh "checkinternet.sh: Passed"
echo "Internet OK"           

