PATH=$PATH:/root
SVR=$(uci get baking.server)
name=$(uci get system.@system[0].hostname)
dns=$(uci get snmpd.@system[0].sysName)
plan=$(uci get baking.plan)
mac=$(sh getmac.sh)
d=$(uci get baking.speedtest_$1_server 2&> /dev/null | wc -l)
if [ $d -eq 1 ] ; then
  if [ "$2" == "VEL" ] ; then        
    v_D=$(uci get baking.$1_D)
    v_U=$(uci get baking.$1_U)
    OKvD=$(sh /tmp/bsw/$1bandwidthdownOK.sh)
    OKvU=$(sh /tmp/bsw/$1bandwidthupOK.sh)
    let v_D=$v_D*1024
    let v_U=$v_U*1024
    gg=$(uci get baking.groupname)
    if [ "$gg" == "NEUTRALIDAD" ] ; then
      if [ $OKvD -eq 0 ] ; then
        vel=$(sh /tmp/bsw/$1bandwidthdown.sh)
        wget --timeout=5 -O /tmp/trap.txt "http://$SVR/linksys/trap.php?item=$2&mac=$mac&type=$1&dir=DOWN&name=$name&dns=$dns&vel=$vel&nominal=$v_D&plan=$plan&trap=trapb" 2> /dev/null 1>/dev/null
      fi 

      if [ $OKvU -eq 0 ] ; then
        vel=$(sh /tmp/bsw/$1bandwidthup.sh)
        wget --timeout=5 -O /tmp/trap.txt "http://$SVR/linksys/trap.php?item=$2&mac=$mac&type=$1&dir=UP&name=$name&dns=$dns&vel=$vel&nominal=$v_U&plan=$plan&trap=traps" 2> /dev/null 1>/dev/null
      fi
    fi
    
    OKvD=$(sh /tmp/bsw/$1bandwidthdownspeedOK.sh)
    OKvU=$(sh /tmp/bsw/$1bandwidthupspeedOK.sh)
    if [ "$gg" == "FDT" ] ; then
      if [ $OKvD -eq 0 ] ; then
        vel=$(sh /tmp/bsw/$1bandwidthdown.sh)
        wget --timeout=5 -O /tmp/trap.txt "http://$SVR/linksys/trap.php?item=$2&mac=$mac&type=$1&dir=DOWN&name=$name&dns=$dns&vel=$vel&nominal=$v_D&plan=$plan&trap=trapb" 2> /dev/null 1>/dev/null
      fi 
      if [ $OKvU -eq 0 ] ; then
        vel=$(sh /tmp/bsw/$1bandwidthup.sh)
        wget --timeout=5 -O /tmp/trap.txt "http://$SVR/linksys/trap.php?item=$2&mac=$mac&type=$1&dir=UP&name=$name&dns=$dns&vel=$vel&nominal=$v_U&plan=$plan&trap=traps" 2> /dev/null 1>/dev/null
      fi
    fi
  fi
fi
d=$(uci get baking.ping_$1_server 2&> /dev/null | wc -l)
if [ $d -eq 1 ] ; then
  if [ "$2" == "PING" ] ; then
    p=$(uci get baking.ping_$1\_latencia)
    OKp=$(sh /tmp/bsw/$1pingOK.sh)
    if [ $OKp -eq 0 ] ; then
      vel=$(sh /tmp/bsw/$1pingICMP_Echo_Replies_received.sh)
      wget --timeout=5 -O /tmp/trap.txt "http://$SVR/linksys/trap.php?item=$2&mac=$mac&type=$1&dir=$2&name=$name&dns=$dns&vel=$vel&nominal=$p&plan=$plan&trap=trapp" 2> /dev/null 1>/dev/null
    fi
  fi
fi
d=$(uci get baking.renew)
if [ $d -ne 0 ] ; then
  if [ "$2" == "RENEW" ] ; then
    OKr=$(sh /tmp/bsw/iploginOK.sh)  
    p=$(uci get baking.renew)
    if [ $OKr -eq 0 ] ; then
       vel=$(sh /tmp/bsw/iploginrenew.sh)
       wget --timeout=5 -O /tmp/trap.txt "http://$SVR/linksys/trap.php?item=$2&mac=$mac&type=$1&dir=$2&name=$name&dns=$dns&vel=$vel&nominal=$p&plan=$plan&trap=trapr" 2> /dev/null 1>/dev/null
    fi
  fi
fi

