PATH=$PATH:/root

touch /tmp/nextrun.txt

while [ 1 ]
do
  w=$(cat /tmp/nextrun.txt | grep Working | wc -l)
  if [ $w -eq 0 ] ; then
    w=$(uci get system.bswkeepalive)
    if [ $w -eq 0 ] ; then  
      sh keepalive.sh
    fi     
    sleep 300
  else
    sleep 10
  fi
done

