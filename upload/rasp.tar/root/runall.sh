# Baking Software 2012
# VERSION=26.03.2013.a

PATH=$PATH:/root

clear
if [ -f /etc/banner ] ; then
  cat /etc/banner
else
  cat banner
fi

echo ">Initializing system"

cd /root
mkdir /tmp/bsw >& /dev/null
mkdir /root/bsw >& /dev/null
mksir /etc/gcom 2>/dev/null
if [ ! -e /tmp/nextrun.txt ] ; then
  > /tmp/nextrun.txt
fi
sh clean.sh
sh httppage.sh
dns=$(grep Configuration /etc/dnsmasq.conf | wc -l)
if [ $dns -eq 0 ] ; then
  echo address=\"\/router.lan\/$(uci get network.lan.ipaddr)\" > /etc/dnsmasq.conf
  /etc/init.d/dnsmasq reload
fi
uci set system.bswkeepalive=0
uci commit 
echo "Starting. Check Internet" >status
sh log.sh "runall.sh: Starting router"
if [ -f /etc/init.d/uhttpd ] ; then
  /etc/init.d/uhttpd restart
else
  service httpd restart
fi
ps | grep http.sh | grep -v grep | awk '{system("kill -9 " $1)'}
sh http.sh 2>&1 > /dev/null &
sh firewall.sh
echo "BSW System Boot" >status
sh httppage.sh
if [ "$1" != "fast" ] ; then
  echo ">Sleeping 60 seconds to allow login"
  sleep 60
fi
# Check for internet
sh checkinternet.sh
echo "> Syncronizing time"
ntp=$(type ntpdate 2>/dev/null | wc -l)
if [ $ntp -eq 1 ] ; then
  ntpdate -s pool.ntp.org
else
  rdate=$(type rdate | awk '{ print $3}')
  $rdate -s nist1.symmetricom.com
fi

if [ -s /proc/kcore ] ; then
  uci set baking.kcore="@/proc/kcore"
else
  dd if=/dev/zero of=/tmp/kcore bs=3000000 count=2
  uci set baking.kcore="@/tmp/kcore"
fi

# sh setup.sh
if [ "$1" != "RESTORE" ] ; then
  sh poweroff.sh &
  dd=$(date +"%s")
  echo $dd > lastboot
fi
if [ ! -e lastboot ] ; then
  dd=$(date +"%s")
  echo $dd > lastboot
fi
sh quote.sh
uci show baking | grep ITEM | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null
uci show baking | grep speedtest_ | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null
uci show baking | grep ping_ | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null

echo "Starting. Stopping Running Applications" > status
echo ">Stopping Applications"
sh httppage.sh
ps | grep bswloop.sh | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep curl.sh | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep bswcheck.sh | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep sleep | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep curl | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep ifstat | grep -v grep | awk '{system("kill -9 " $1)'}

uci set baking.start=$(date +"%s")
uci set baking.stop=$(date +"%s")
uci commit

f=$(uci show firewall | grep dest_port=1161 | wc -l)
if [ $f -eq 0 ] ; then
  echo ">Add 1161 to firewall"
  uci add firewall rule              
  uci set firewall.@rule[-1].src=wan
  uci set firewall.@rule[-1].target=ACCEPT
  uci set firewall.@rule[-1].proto=udp
  uci set firewall.@rule[-1].dest_port=1161
  uci commit firewall 
  sh firewall.sh
fi
if [ -f /etc/snmp/snmpd.conf ] ; then
  sp=$(grep agentaddress /etc/snmp/snmpd.conf | wc -l)
  if [ $sp -eq 0 ] ; then
    echo "agentaddress :1161" >> /etc/snmp/snmpd.conf
  fi
fi
uci set snmpd.@system[0].sysName=$(sh getmac.sh  | awk '{ gsub(":",""); print "BSW" $1}')
uci set system.bswkeepalive=0
uci commit            
echo ">Restarting SNMP"
echo ">Restarting cron"
if [ -f /etc/init.d/cron ] ; then
  /etc/init.d/snmpd restart
  /etc/init.d/cron restart
else
  service crond restart
  service snmpd restart
fi

rm /etc/config/ntpclient 2> /dev/null
killall ntpclient 2> /dev/null          

echo "Staring BSW Applications" > status
echo ">Starting BSW Applications"
sh httppage.sh
cp /root/bsw/* /tmp/bsw 2> /dev/null
rm /tmp/config.sh 2> /dev/null
pc=$(uci get baking.pcontrol)                                                                           
if [ "$pc" == "1" ] ; then                                                                            
  sh pcontrol.sh                                                                                        
fi                                                                                                      
sh bswcheck.sh 2>&1 > /dev/null &
sh bswloop.sh 2>&1 > /dev/null &
echo "Operational" > status
sh log.sh "runall.sh: Completed"
echo ">Initialization Complete"
sh httppage.sh
echo ""


