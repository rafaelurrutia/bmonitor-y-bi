PATH=$PATH:/root

