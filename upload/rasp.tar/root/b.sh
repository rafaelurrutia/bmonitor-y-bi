( 
  flock -e 200
  echo "In critical section"
  sleep 5 
) 200>/tmp/blah.lockfile 
echo "After critical section"
