PATH=$PATH:/root

echo "Operational. Sending Traps to Server" >status
echo ">Sending Traps to Server"
sh checkinternet.sh
sh log.sh "trap.sh: Sending Traps to server"
sh sendtrap.sh NAC VEL
sh sendtrap.sh INT VEL
sh sendtrap.sh LOC VEL

sh sendtrap.sh NAC PING
sh sendtrap.sh INT PING
sh sendtrap.sh LOC PING

sh sendtrap.sh RENEW RENEW
