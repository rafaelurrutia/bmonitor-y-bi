# Baking Software
# Initialization script

cd /tmp
echo "Got upgrade signal. Upgrading..." > /tmp/status
SERVER1=$(uci get baking.server1)
SERVER2=$(uci get baking.server2)
SERVER=""
                                                                                              
cat /etc/config/baking | grep -v 'ITEM' | awk '{ if (length($0) != 0) print $0}' > /tmp/baking
mv /tmp/baking /etc/config/baking
file=raspibsw.tar
OK=0                                                                                                
rsize=$(curl -s --head URL http://$SERVER1/linksys/$file | grep "Content-Length" | awk '{print $2*1}')
if [ "$rsize" != "" ] ; then                            
  SERVER=$SERVER1                                       
else                                                    
  rsize=$(curl -s --head URL http://$SERVER2/linksys/$file | grep "Content-Length" | awk '{print $2*1}')
  if [ "$rsize" != "" ] ; then                          
    SERVER=$SERVER2                                     
  fi
fi
echo "Local File Size: .. $rsize .."
wget -q -T5 -O raspibsw.tar http://$SERVER/linksys/$file
if [ $? -eq 0 ] ; then           
  if [ -s /tmp/raspibsw.tar ] ; then
    lsize=$(ls -al /tmp/raspibsw.tar | awk '{print $5}')
    echo "Remote File Size: .. $lsize .."
    if [ "$rsize" == "$lsize" ] ; then
      echo ">CRC OK"
      OK=1
    else
      echo ">CRC FAIL"
    fi
  fi                      
  if [ $OK -eq 1 ] ; then                           
    cd /
    echo ">UNTAR"
    tar xvf /tmp/raspibsw.tar 2>/dev/null
    echo ">"
    echo ">SYSCTL"
    sysctl -p  
    echo ">"
    cd /root                                          
    v=$(cat /etc/config/system | grep version | wc -l)
    if [ $v -eq 0 ] ; then            
      uci set system.version="0.0.0.0"
    fi                                                  
    uci set system.lastupdate=$(date +"%Y-%m-%d_%H-%M-%S")
    service httpd restart
    echo ">RESTORE COMPLETED"
    sh runall.sh "RESTORE"
  else           
    cd /root       
    sleep 5        
    sh restore.sh &
  fi             
else             
  cd /root
  sleep 5
  sh restore.sh &
fi
                                                                                                                                
