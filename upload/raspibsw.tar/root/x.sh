for f in $(ls -1 /tmp/bsw)
do
  item=$(echo $f | awk '{gsub(".sh",""); print "ITEM"$1}')
  uci get baking.$item
done
