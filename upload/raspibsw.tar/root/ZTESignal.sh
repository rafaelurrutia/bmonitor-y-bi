cnt=0

while [ $cnt -le 10  ] ;
do
  signal=$(/root/ZTESignal.py 2>/dev/null| grep "+csq:" | tail -1 | awk 'BEGIN {FS=","}{ snr=substr($1,6);signal=-113-snr*2;print -signal}')
  if [ "$signal" != "" ] ; then
    echo $signal
    cnt=100
  else
    let cnt=cnt+1
  fi
done
