cnt=0

while [ $cnt -le 10  ] ;
do
  rssi=$(/root/ZTESignal.py 2>/dev/null| grep "+csq:" | tail -1 | awk 'BEGIN {FS=","}{ snr=substr($1,6);print snr}')
  if [ "$rssi" != "" ] ; then
    if [ $rssi -gt 25 ]; then
        echo "Excellent"
    elif [ $rssi -gt 19 ] && [ $rssi -le 25 ]; then
        echo "Good"
    elif [ $rssi -gt 13 ] && [ $rssi -le 19 ]; then
        echo "Average"
    elif [ $rssi -gt 7 ] && [ $rssi -le 13 ]; then
        echo "Low"
    elif [ $rssi -gt 0 ] && [ $rssi -le 7 ]; then
        echo "Very low"
    else
        echo "No signal"
    fi
    cnt=100
  else
    let cnt=cnt+1
  fi
done
