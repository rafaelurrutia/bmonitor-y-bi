#!/bin/bash
eth=$(netstat -nr | grep "^0.0.0.0" |awk '{print $8}')
ip=`ip addr | grep "inet " | grep $eth | awk '{print substr($2,0)}' | cut -d "/" -f1`
echo $ip;
