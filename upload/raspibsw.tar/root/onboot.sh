export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin:/root
cd /root
v1=$(ps -fea | grep runall | grep -v grep | wc -l)
v2=$(ps -fea | grep bswloop | grep -v grep | wc -l)
v3=$(ps -fea | grep keepalive | grep -v grep | wc -l)
echo "runall:$v1 bswloop:$v2 keepalive:$v3" > /tmp/system.txt
if [ $v1 -eq 0 ] && [ $v2 -eq 0 ] && [ $v3 -eq 0 ] ; then
  echo "Staring system" >> /tmp/system.txt
  
  dd=$(date +"%s")
  echo $dd > lastboot
  
  if [ -s /root/runall.sh ] ; then
    sh /root/runall.sh $1&
  else
    sh /root/restore.sh &
  fi
else
  echo "System already running" >> /tmp/system.txt
fi
