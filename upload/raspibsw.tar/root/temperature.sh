modprobe w1-gpio
modprobe w1-gpio
ok=0
dir=$(ls -1 /sys/bus/w1/devices |grep "28-" 2>/dev/null)
if [ "$dir" != "" ] ; then
 td=/sys/bus/w1/devices/$dir/w1_slave
 ok=1
fi
d=$(date)
t=$(vcgencmd measure_temp)
v=$(vcgencmd measure_volts)
tl=$(vcgencmd get_config int | grep limit)
if [ $ok -eq 1 ] ; then
  out=$(cat $td  | grep "t=" | awk 'BEGIN {FS="="}{print int($2/100)/10}')
else
  out=0.0
fi
iface=$(uci get system.iface)
bat="N/A"
cpu="N/A"
if [ "$iface" == "PHONE" ] ; then
  cpu=$(adb shell cat /sys/class/thermal/thermal_zone0/temp | tr -dc '[[:print:]]')
  nok=$(echo $cpu | grep system | wc -l)
  if [ $nok -eq 1 ] ; then
    cpu="N/A"
  fi
  bat=$(adb shell cat /sys/class/power_supply/battery/device/power_supply/battery/temp | awk '{print int($0/10)}' | tr -dc '[[:print:]]')  
fi
data="$d $t $v $tl.0'C out=$out'C batt=$bat'C android=$cpu'C"
echo $data >> /root/temperature/temperature.log
data="$t box=$out'C batt=$bat'C android=$cpu'C"
echo $data
