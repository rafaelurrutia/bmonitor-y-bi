ip addr add 10.0.0.3/24 dev eth0
ip route add default via 10.0.0.2
