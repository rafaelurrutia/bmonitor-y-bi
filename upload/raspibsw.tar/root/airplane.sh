
ok=0
if [ "$1" == "off" ] ; then
  adb shell settings put global airplane_mode_on 0
  adb shell am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false
  ok=1
fi

if [ "$1" == "on" ] ; then
  adb shell settings put global airplane_mode_on 1
  adb shell am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true
  ok=1
fi

if [ $ok -eq 0 ] ; then
  echo "airplane on|off"
fi
