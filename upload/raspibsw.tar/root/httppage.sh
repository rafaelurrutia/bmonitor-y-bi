cd /root
PATH=$PATH:/root

p=$(ps -fea | grep httppage.sh  | grep -v grep | wc -l)
if [ $p -ge 4 ] ; then
  echo Exit $p
  exit
fi

quote=""
if [ -d /www ] ; then
  w=/www/index.html
else
  w=/var/www/html/index.html
fi

iface=$(uci get system.iface)
if [ "$iface" == "TL-MR3020" ] ; then
  data=$(curl --user admin:admin "http://192.168.0.254/userRpm/StatusRpm.htm" -H "Referer: http://192.168.0.254/userRpm/StatusRpm.htm" -H "Cookie: Authorization='Basic YWRtaW46YWRtaW4='" -s | awk '{ printf("%s",$0) }' | awk 'BEGIN {FS="mobileParam"}{ print $2}' | awk 'BEGIN {FS=";"} {print substr($1,14)}')
  echo $data | awk 'BEGIN {FS="\""}{dns=$12;up=$14;gsub(",","");gsub(" ","");if ($1=="0") status="Unplugged";if ($1=="1") status="Identifying";if ($1=="2") status="Identified";if ($1=="3") sttaus="Charging";if ($1=="4") status="Unknown"; print "Status   : "status"\nCode     : "$1"\nSignal   : "$3"%\nIP       : "$6"\nMASK     : "$8"\nGW       : "$10"\nDNS      : "dns"\nUptime   : "up}' > /tmp/tpdata
  curl --user admin:admin "http://192.168.0.254/userRpm/StatusRpm.htm" -H "Referer: http://192.168.0.254/userRpm/StatusRpm.htm" -H "Cookie: Authorization='Basic YWRtaW46YWRtaW4='" -s | awk '{ printf("%s",$0) }' | awk 'BEGIN {FS="statistList"}{ print $2}' | awk 'BEGIN {FS=";"} {print substr($1,14)}' | awk '{gsub(",","");print "IN       : "$1"\nOUT      : "$2"\n"}' >> /tmp/tpdata
fi 
SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
SVR=$(uci get baking.server)
com=$(cat /proc/cpuinfo | grep "cpu model\|Serial" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
rou=$(cat /proc/cpuinfo | grep "machine\|Hardware" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
boa=$(cat /proc/cpuinfo | grep "system type\|model name" | tail -1 | awk 'BEGIN { FS=":"} { print substr($2,2) }')
nextrun=""
ttime=""
if [ -f /tmp/nextrun.txt ] ; then
  nextrun=$(cat /tmp/nextrun.txt)
fi
if [ -s /tmp/testduration ] ; then
  ttime=$(cat /tmp/testduration)
  if [ -s /tmp/bsw/u.txt ] ; then
    tdate=$(cat /tmp/bsw/u.txt | awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')
    ttime="$ttime @ $tdate" 
  fi
else
  ttime=""
fi
st=$(cat /tmp/status 2> /dev/null)
mac=$(sh getmac.sh)
par=$(uci get baking.pcontrol 2&> /dev/null)
hos=$(uci get system.@system[0].hostname 2&> /dev/null) 
if [ "$hos" == "" ] ; then
  hos=$(cat /etc/hostname)
fi
if [ "$hos" == "" ] ; then
  hos=$(uci get system.system0.hostname 2&> /dev/null) 
fi
ip=$(uci -P /var/state get network.wan.ipaddr 2&> /dev/nul)
[ $? -eq 1 ] && { # si la conexión es ip fija, la wan ip no está en /var/state/network sino en /etc/config/network, entonces la sacamos de ahí.
    ip=$(uci get1 network.wan.ipaddr 2&> /dev/nul)
}
if [ "$ip" == "" ] ; then
  eth=$(sh geteth.sh)
  ip=$(ifconfig $eth | grep "inet " | awk '{ print $2}')
fi
if [ "$ip" == "" ] ; then
  ip=$(ip.sh 2>/dev/null | grep Address | awk '{ print $2 }')
fi
lio=$(uci -P /var/state get network.lan.ipaddr 2&> /dev/null)
if [ "$lio" == "" ] ; then
  lio="N/A"
fi
if [ "$par" == "1" ] ; then
  par="Enabled"
else
  par="Disabled"
fi

ver=$(uci get system.version)
lastboot=$(cat lastboot 2>/dev/null| awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')

rm /www/index.php &> /dev/null
d=$(date)
utime=$(uptime)
uname=$(uname -a | awk 'BEGIN {FS="#"} {print $1}')
vacation=""
vac1=$(uci get baking.ndw1 2&> /dev/null)
vac2=$(uci get baking.ndw2 2&> /dev/null)
if [ "$vac1" != "" ] ; then
  ddt=$(date +"%s")
  if [ $vac2 -gt $ddt ] ; then
    v1=$(echo $vac1 | awk '{ print strftime("%d/%m/%Y",$1+3600*3)}')
    v2=$(echo $vac2 | awk '{ print strftime("%d/%m/%Y",$1-3600*3)}')
    vacation="$v1 - $v2"
  fi
fi
working=$(uci get baking.horario 2> /dev/null)
plan=$(uci get baking.plan 2> /dev/null)
delay=$(uci get baking.delay 2> /dev/null)
wf=$(uci get wireless.radio0.disabled 2> /dev/null)
nwd=$(uci get baking.feriados 2> /dev/nyll)
if [ "$wf" == "1" ] || [ "$wf" == "" ] ; then
  wf="Disabled"
else
  wf="Enabled"
fi

if [ -e /tmp/config.sh ] ; then
  dt=$(cat /tmp/lastconfig)
  conf="Yes [$dt]"
else
  conf="No"
  plan=""
  delay=""
  working=""
  state="Idle"
fi

x=$(uci show system | grep status | wc -l)     
if [ $x -eq 1 ] ; then                         
  xst=$(uci get system.status)                  
  if [ $xst -eq 1 ] ; then                      
    st="Router disabled on server"
    ttime="00:00:00"
  fi                                                             
fi        
temp=$(vcgencmd measure_temp | awk '{gsub("temp=",""); print $0}')
tempm=$(cat /tmp/tempin.log 2>/dev/null | sort | tail -1)
tempmax=$(cat /tmp/maxtempin 2>/dev/null)
tempmaxdate=$(cat /tmp/maxtempdatein 2>/dev/null)

if [ "$tempm" == "" ] ; then
  tempm="N/A"
fi
if [ "$tempmax" == "" ] ; then
  tempmax="N/A"
fi

cpuTemp0=$(cat /sys/class/thermal/thermal_zone0/temp)
cpuTemp1=$(($cpuTemp0/1000))
cpuTemp2=$(($cpuTemp0/100))
cpuTempM=$(($cpuTemp2 % $cpuTemp1))

ok=0
dir=$(ls -1 /sys/bus/w1/devices |grep "28-" 2>/dev/null)
if [ "$dir" != "" ] ; then
 td=/sys/bus/w1/devices/$dir/w1_slave
 ok=1
fi
d=$(date)
t=$(vcgencmd measure_temp)
v=$(vcgencmd measure_volts)
tl=$(vcgencmd get_config int | grep limit)
if [ $ok -eq 1 ] ; then
  tempout=$(cat $td  | grep "t=" | awk 'BEGIN {FS="="}{print int($2/100)/10}')
else
  tempout=0.0
fi

tempmaxout=$(cat /tmp/maxtempout 2>/dev/null)
tempmaxdateout=$(cat /tmp/maxtempdateout 2>/dev/null)

echo "" > $w
echo '<html xmlns="http://www.w3.org/1999/xhtml">' >> $w
echo '<head>' >> $w
echo '<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />' >> $w
echo '<meta http-equiv="refresh" content="15" />' >> $w
echo '<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE" />' >> $w
echo '<META HTTP-EQUIV="EXPIRES" CONTENT="-1" />' >> $w
echo '<title>::Baking Sofware - bFirmware - 2011</title>' >> $w
echo '</head>' >> $w
echo '<a href="http://www.bsw.cl"><img src="logo.jpg" width="300" height="71" alt="BakingSoftware" /></a>' >> $w
echo "<center><big>" >> $w
echo "<table boder=1 cellspacing=0>" >> $w
echo "<tr><td>Router</td><td>$hos</td></tr>" >> $w
echo "<tr><td>MAC</td><td>$mac</td></tr>" >> $w
echo "<tr><td>Plan</td><td>$plan</td></tr>" >> $w
echo "<tr><td>Public IP</td><td>$ip</td></tr>" >> $w
echo "<tr><td>Local IP</td><td>$lio</td></tr>" >> $w
echo "<tr><td>Version</td><td>$ver</td></tr>" >> $w
echo "<tr><td>Board</td><td>$boa</td></tr>" >> $w
echo "<tr><td>Machine</td><td>$rou</td></tr>" >> $w
echo "<tr><td>Model</td><td>$com</td></tr>" >> $w
echo "<tr><td>Connection Type</td><td>" $(uci get system.iface) "</td></tr>" >> $w
echo "<tr><td>CPU Temp</td><td>$cpuTemp1.$cpuTempM'C</td></tr>" >> $w
echo "<tr><td>GPU Temp</td><td>$temp</td></tr>" >> $w
echo "<tr><td>Last process Temp</td><td>$tempm'C</td></tr>" >> $w
echo "<tr><td>Max Temp</td><td>$tempmax'C at $tempmaxdate</td></tr>" >> $w
echo "<tr><td>Outside Temp</td><td>$tempout'C</td></tr>" >> $w
echo "<tr><td>Max Temp Outside&nbsp;&nbsp;</td><td>$tempmaxout'C at $tempmaxdateout</td></tr>" >> $w
xtemp=$(sh temperature.sh)
echo "<tr><td>Temp&nbsp;&nbsp;</td><td>$xtemp</td></tr>" >> $w
echo "<tr><td>WiFi</td><td>$wf</td></tr>" >> $w
echo "<tr><td>Parental Control</td><td>$par</td></tr>" >> $w
echo "<tr><td>Config File</td><td>$conf</td><tr>" >> $w
echo "<tr><td>Active Server</td><td>$SVR</td></tr>" >> $w
echo "<tr><td>Server 1</td><td>$SVR1</td></tr>" >> $w
echo "<tr><td>Server 2</td><td>$SVR2</td></tr>" >> $w
echo "<tr><td>Status</td><td>$st</td></tr>" >> $w
echo "<tr><td>Next run</td><td>$nextrun</td></tr>" >> $w
echo "<tr><td>Run every</td><td>$delay seconds</td></tr>" >> $w
echo "<tr><td>Working hours</td><td>$working</td></tr>" >> $w
echo "<tr><td>Vacations</td><td>$vacation</td></tr>" >> $w
echo "<tr><td>Hollidays</td><td>$nwd</td></tr>" >> $w
echo "<tr><td>Last update</td><td>$d</td></tr>" >> $w
echo "<tr><td>Test duration</td><td>$ttime</td></tr>" >> $w
if [ "$iface" == "TL-MR3020" ] ; then
   echo "<tr><td>3G/4G Signal </td><td>$(cat /tmp/tpdata | grep Signal | awk '{print $3}')</td></tr>" >> $w
   echo "<tr><td>3G/4G IP </td><td>$(cat /tmp/tpdata | grep IP | awk '{print $3}')</td></tr>" >> $w
   echo "<tr><td>3G/4G GW </td><td>$(cat /tmp/tpdata | grep GW | awk '{print $3}')</td></tr>" >> $w
   echo "<tr><td>3G/4G Mask </td><td>$(cat /tmp/tpdata | grep MASK | awk '{print $3}')</td></tr>" >> $w
   echo "<tr><td>3G/4G DNS </td><td>$(cat /tmp/tpdata | grep DNS | awk '{print $3,$4,$5}')</td></tr>" >> $w
   echo "<tr><td>3G/4G BYTES IN </td><td>$(cat /tmp/tpdata | grep IN | awk '{print $3}')</td></tr>" >> $w
   echo "<tr><td>3G/4G BYTES OUT&nbsp;&nbsp;&nbsp;</td><td>$(cat /tmp/tpdata | grep OUT | awk '{print $3}')</td></tr>" >> $w
   echo "<tr><td>3G/4G Uptime </td><td>$(cat /tmp/tpdata | grep Uptime | awk '{print $3,$4,$5}')</td></tr>" >> $w
fi
if [ "$iface" == "PHONE" ] ; then
  net=$(adb shell dumpsys connectivity | grep Network | grep "mobile\[" | awk '{print substr($3,8,length($3)-9)} ')
  echo "<tr><td>Network </td><td>$net</td></tr>" >> $w
  conn=$(adb shell dumpsys connectivity | grep Network | grep "mobile\[" | awk '{print substr($5,1,length($5)-1)} ')
  echo "<tr><td>Connection Status </td><td>$conn</td></tr>" >> $w
  sgn=$(adb shell dumpsys telephony.registry | grep mSignalStrength | awk '{print $2,$3,$4,$5,$6,$7,$8,$9}')
  echo "<tr><td>Signal </td><td>$sgn</td></tr>" >> $w
fi
echo "<tr><td>System </td><td>$uname</td></tr>" >> $w
echo "<tr><td>Uptime </td><td>$utime</td></tr>" >> $w
echo "<tr><td>Last Boot </td><td>$lastboot</td></tr>" >> $w
echo "</table>" >> $w
echo "</big></center>" >> $w
#q=$(cat quote.txt)
#echo "<br><br><center><big><italic>$q</italic></big></center>" >> $w
dd=$(date +"%s")
echo $dd > /tmp/lastalive

