PATH=$PATH:/root
SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
SVR=$SVR1
clock=$(cat /tmp/lastalive)
mac=$(sh getmac.sh)
r=""
while [ "$r" == "" ] ; do
  rm /tmp/poweroff >& /dev/null
  wget -q -T 2 -O /tmp/poweroff "http://$SVR1/linksys/poweroff.php?clock=$clock&mac=$mac" &> /dev/null
  g=$(cat /tmp/poweroff | grep END | wc -l)
  if [ $g -eq 0 ] ; then
    rm /tmp/poweroff >& /dev/null
  fi
  if [ -s /tmp/poweroff ] ; then
    SVR=$SVR1
    uci set baking.server=$SVR

  else
    wget -q -T 2 -O /tmp/poweroff "http://$SVR2/linksys/poweroff.php?clock=$clock&mac=$mac" &>/dev/null
    g=$(cat /tmp/poweroff | grep END | wc -l)
    if [ $g -eq 0 ] ; then
      rm /tmp/poweroff >& /dev/null
    fi
    if [ -s /tmp/poweroff ] ; then
      SVR=$SVR2
      uci set baking.server=$SVR

    fi
  fi
  r=$(cat /tmp/poweroff | grep END | wc -l) 
done


