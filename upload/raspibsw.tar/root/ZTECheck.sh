
echo $(date) "ZTECheck Interface"
ok=0
while [ $ok -eq 0 ] ;
do
  ppp=$(ifconfig | grep ppp0 | wc -l)
  if [ $ppp -eq 1 ] ; then
    ch=$(ping -c 2 200.28.4.129 | grep "1 received,\|2 received"| wc -l)
  else
    ch=0
    echo $(date) "ZTECheck Interface ppp0 Down"
  fi
  if [ $ch -eq 0 ] ; then
    echo $(date) "ZTECheck Modem Reset Start"
    sh ZTEConnect.sh
    echo $(date) "ZTECheck Modem Reset Complete"
  else
    ok=1
  fi
done 
