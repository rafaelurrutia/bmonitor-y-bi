PATH=$PATH:/root
f=$(type flock 2> /dev/null | wc -l)
if [ $f -eq 1 ] ; then 
(
  flock -e 200
  d=$(date)
  max=100
  n=$(cat /tmp/panic | wc -l)
  if [ $n -ge $max ] ; then
    tail -$max /tmp/panic > /tmp/p.txt
    mv /tmp/p.txt /tmp/panic
  fi
  echo "$d $1"  >> /tmp/panic
  echo "$d $1"
)  200>/tmp/blah2.lockfile 
fi
