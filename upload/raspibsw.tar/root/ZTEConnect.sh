echo $(date) "Modem Connect Killng wvdial"
if [ -s /tmp/ZTE ] ; then
  z=$(cat /tmp/ZTE)
  if [ $z -eq 1 ] ; then
    exit
  fi
fi
echo 1 > /tmp/ZTE
killall wvdial &>/dev/null
mknod /dev/ppp c 108 0 2>/dev/null
con=0
cnt=0
while [ $con -eq 0 ] ;
do
  let cnt=cnt+1
  echo $(date) "Modem Connect Registering Modem. Attempt $cnt"
  cmd=$(/root/ZTERegister.py 2>/dev/null)
  #echo $cmd
  con=$(echo $cmd | grep "Connected to a cellular network" | wc -l)
  re=$(echo $cmd | grep " Module is not turning on" | wc -l)
  if [ $re -eq 1 ] ; then
    echo $(date) "Module is not turning on the Modem. Rebooting"
    reboot
  fi
done

echo $(date) "Modem Connect Modem Registered"
# /root/sakis3g connect --console --nostorage --pppd  BAUD=115200 CUSTOM_TTY="/dev/ttyAMA0" MODEM="OTHER" OTHER="CUSTOM_TTY" --debug

echo $(date) "Modem Connect Calling wvdial"
nohup wvdial &> /tmp/ppp &

ok=0
cnt=0
while [ $ok -eq 0 ] ;
do
  let cnt=cnt+1
  echo $(date) "Modem Connect Waiting for DNS. Attempt $cnt"
  ok=$(cat /tmp/ppp | grep DNS | awk '{ print "nameserver ",$5}' | wc -l)
  sleep 1
  cat /tmp/ppp | grep DNS | awk '{ print "nameserver ",$5}' > /etc/resolv.conf
  if [ $cnt -ge 25 ] ; then
    echo $(date) "DNS servers can not be indentified. Rebooting"
    reboot
  fi 
done
if [ $cnt -ge 15 ] ; then
  echo $(date) "Modem Connect Error"
else
  route add 200.28.4.129 ppp0
  cat /etc/resolv.conf
  echo $(date) "Modem Connect Done"
fi
echo 0 > /tmp/ZTE
