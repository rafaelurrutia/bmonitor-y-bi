#!/system/bin/sh

adb shell getprop sys.usb.config
adb shell setprop sys.usb.config 'rndis,adb'
adb shell ip rule add from all lookup main
adb shell ip addr flush dev rndis0
adb shell ip addr add 192.168.2.1/24 dev rndis0
adb shell ip link set rndis0 up
adb shell iptables -t nat -I POSTROUTING 1 -o rmnet0 -j MASQUERADE
adb shell echo 1 > /proc/sys/net/ipv4/ip_forward
adb shell dnsmasq --pid-file=/cache/usb_tether_dnsmasq.pid --interface=rndis0 --bind-interfaces --bogus-priv --filterwin2k --no-resolv --domain-needed --server=8.8.8.8 --server=8.8.4.4 --cache-size=1000 --dhcp-range=192.168.2.2,192.168.2.254,255.255.255.0,192.168.2.255 --dhcp-lease-max=253 --dhcp-authoritative --dhcp-leasefile=/cache/usb_tether_dnsmasq.leases < /dev/null
