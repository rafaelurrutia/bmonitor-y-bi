user="admin:bswsysop"
user64=$(echo $user | base64)

data=$(curl --user $user "http://192.168.0.254/userRpm/StatusRpm.htm" -H "Referer: http://192.168.0.254/userRpm/StatusRpm.htm" -H "Cookie: Authorization='Basic $user64'" -s | awk '{ printf("%s",$0) }' | awk 'BEGIN {FS="mobileParam"}{ print $2}' | awk 'BEGIN {FS=";"} {print substr($1,14)}')
echo $data | awk 'BEGIN {FS="\""}{dns=$12;up=$14;gsub(",","");gsub(" ","");if ($1=="0") status="Unplugged";if ($1=="1") status="Identifying";if ($1=="2") status="Identified";if ($1=="3") sttaus="Charging";if ($1=="4") status="Unknown"; print "Status   : "status"\nCode     : "$1"\nSignal   : "$3"%\nIP       : "$6"\nMASK     : "$8"\nGW       : "$10"\nDNS      : "dns"\nUptime   : "up}'
curl --user $user "http://192.168.0.254/userRpm/StatusRpm.htm" -H "Referer: http://192.168.0.254/userRpm/StatusRpm.htm" -H "Cookie: Authorization='Basic $user64'" -s | awk '{ printf("%s",$0) }' | awk 'BEGIN {FS="statistList"}{ print $2}' | awk 'BEGIN {FS=";"} {print substr($1,14)}' | awk '{gsub(",","");print "IN       : "$1"\nOUT      : "$2"\n"}'

