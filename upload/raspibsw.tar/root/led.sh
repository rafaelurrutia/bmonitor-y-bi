
pin=2
if [ ! -s /tmp/led ] ; then
  echo 1 > /tmp/led
fi
while [ 0 ] ;
do
  gpio mode $pin out
  type=$(cat /tmp/led)  
  if [ $type -eq -1 ] ; then  # Booting Begin
    gpio write $pin 1
  fi
  if [ $type -eq -2 ] ; then # No Internet (Checkinternet.sh)
    gpio write $pin 0
    sleep 3
    gpio write $pin 1
    sleep 0.1
  fi
  if [ $type -eq -3 ] ; then # Booting
    gpio write $pin 0
    sleep 5
    gpio write $pin 1
    sleep 1
  fi
  if [ $type -eq -4 ] ; then # Idle
    gpio write $pin 0
    sleep 10
    gpio write $pin 1
    sleep 0.3
    gpio write $pin 0
    sleep 0.3
    gpio write $pin 1
    sleep 0.3
  fi
  if [ $type -eq 0 ] ; then
    ttime=0.5
    gpio write $pin 1
    sleep $ttime
    gpio write $pin 0
    sleep $ttime
  fi
  if [ $type -ge 1 ] ; then
    for f in `seq 1 $type`; do 
      gpio write $pin 1
      sleep 0.1
      gpio write $pin 0
      sleep 0.1
    done
    sleep 1
  fi

done

