nmcli dev wifi con "$1" password "$2"
