cd /root/bsw
rm -f *.tar
cd /
tar -cvf /tmp/raspibsw.tar etc/sysconfig/iptables  var/www/html/* root/uci usr/bin/uci etc/httpd/conf/httpd.conf etc/php.ini root/*.sh etc/crontabs/root etc/httpd/conf root/*.cfg etc/crontabs/root root/cron root/hub-ctrl* root/*.py root/sakis3g etc/wvdial.conf root/*.pyc etc/sakis3g.conf etc/config/phone
# tar -cvf /tmp/raspibsw.tar etc/sysconfig/iptables  var/www/html/* root/uci usr/bin/uci etc/httpd/conf/httpd.conf etc/php.ini root/*.sh etc/crontabs/root etc/httpd/conf root/*.cfg etc/crontabs/root root/cron root/hub-ctrl* root/*.py root/sakis3g etc/wvdial.conf root/*.pyc etc/sakis3g.conf etc/config

#echo "GIT"
#echo "------------------------------------------"
#cd /home/baking/repos/qos
#tar xvf /tmp/raspibsw.tar
#cd /tmp

curl $(uci get baking.server | awk '{print $1}' FS=":")/api/backup -F "file=@/tmp/raspibsw.tar" -X POST
# curl $(echo bmonitor.baking.cl | awk '{print $1}' FS=":")/api/backup -F "file=@/tmp/raspibsw.tar" -X POST
