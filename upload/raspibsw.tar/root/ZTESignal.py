#!/usr/bin/python

import SparqEE #version 1
import re
import signal
import sys
from time import sleep
import RPi.GPIO as GPIO
import serial

# GLOBALS --------------------------------------------------------------------

SparqEE.glob_debug = 5                      #Override global debug print level   
ser = serial.Serial(port='/dev/ttyAMA0', baudrate=115200, timeout=3)    #serial port

def debug(str):
    SparqEE.debug_print( str, SparqEE.debug["DEBUG"] )

def debug2(cmd, ret):
    debug(cmd)
    debug( "---> CMD RET --->: " + str(ret) )
    debug( "---> BUFFER  --->" + SparqEE.buffer )

def cmd_full(string, tries, delay, search = "OK"):
    global buffer
    buffer = ""
    while (tries > 0):              #"command" is executed a maximum number of tries
      try:
        ser.write("at" + string + "\r")           #write to modem
        sleep(delay)
        b=ser.inWaiting()
        buffer = ser.read(b)
        if (buffer.find(string) >= 0):
          print( buffer )
          return 0
        else:
          tries-=1
      finally:
        tries-=1
    return 1

#-----------------------------------------------------------------------------

cmd_full("+csq", 20, 1)

