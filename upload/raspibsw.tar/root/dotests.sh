export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin:/root

volt=$(vcgencmd measure_volts | awk 'BEGIN {FS="="}{print int($2*10)}')
if [ $volt -le 11 ] ; then
  exit
fi
echo ">Starting test"
sh log.sh "dotests.sh: Tests Begin"
ps -fea | grep maxtemp  | grep -v grep | awk '{ print $2 }' | xargs kill -9 2>/dev/null
sh maxtemp.sh &
sh checkinternet.sh

ntp=$(type ntpdate 2>/dev/null | wc -l)
if [ $ntp -eq 1 ] ; then
  ntpdate -s pool.ntp.org 
else 
  rdate=$(type rdate | awk '{ print $3}')
  $rdate -s nist1.symmetricom.com
fi

fs=$(df -k /tmp | grep -v Filesystem | awk '{if ($4>1200) print 1; else print 0;}')

if [ $fs -eq 0 ] ; then
  sh log.sh "Too many test pending to post. Aborting this test"
  exit
fi


x=$(uci show baking | grep feriados | wc -l)
if [ $x -eq 1 ] ; then
  clock="NODATES"
  clock=$(uci get baking.feriados)
  go=0
  if [ "$clock" != "" ] ; then
    d=$(date +"%d/%m")
    go=$(echo $clock $d | awk '{print match($1,$2)}')
  fi  

  if [ $go -ne 0 ] ; then
    echo "No working day. Exit"
    exit
  fi
fi

x=$(uci show system | grep status | wc -l)
if [ $x -eq 1 ] ; then
  st=$(uci get system.status)
  if [ $st -eq 1 ] ; then
    echo "Router disabled on server. Exit"
    exit
  fi
fi
OK1=$(sh cdate.sh $(uci get baking.horario))
if [ "$OK1" == "NO" ] ; then
  echo "WARNING. YOU ARE RUNNING THE TEST ON NON OPERATIONAL HOUR"
fi

echo "Operational. Preparing for Test" > /tmp/status
(gpio mode 0 out; gpio write 0 1; sleep 0.005;gpio write 0 0) &

u=$(date +"%s")
echo $u > /tmp/bsw/u.txt
iface=$(uci get system.iface)
uci set baking.u=$u
echo 1 > /tmp/led
rm /tmp/bsw/NACband* >& /dev/null
d=$(uci get baking.speedtest_NAC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download NAC speedtest"
  sh dospeedtestD.sh NAC 1 0
  c=$(sh /tmp/bsw/NACbandwidthdownOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACbandwidthdown.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthdown.sh
    m=$(sh /tmp/bsw/NACbandwidthdownif.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthdownif.sh
    m=$(sh /tmp/bsw/NACbandwidthbytedown.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthbytedown.sh
    m=$(sh /tmp/bsw/NACbandwidthtimedown.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthtimedown.sh
  fi
  echo ">Running upload NAC speedtest"
  sh dospeedtestU.sh NAC 1 0
  c=$(sh /tmp/bsw/NACbandwidthupOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACbandwidthup.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthup.sh
    m=$(sh /tmp/bsw/NACbandwidthupif.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthupif.sh
    echo "echo -$m" > /tmp/bsw/NACbandwidthbandwidthupif.sh
    m=$(sh /tmp/bsw/NACbandwidthbyteup.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthbyteup.sh
    m=$(sh /tmp/bsw/NACbandwidthtimeup.sh)
    echo "echo -$m" > /tmp/bsw/NACbandwidthtimeup.sh
  fi
fi
rm /tmp/bsw/LOCband* >& /dev/null
d=$(uci get baking.speedtest_LOC_server 2> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download LOC speedtest"
  sh dospeedtestD.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCbandwidthdownOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCbandwidthdown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdown.sh
    m=$(sh /tmp/bsw/LOCbandwidthdownif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthdownif.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbandwidthdownif.sh
    m=$(sh /tmp/bsw/LOCbandwidthbytedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbytedown.sh
    m=$(sh /tmp/bsw/LOCbandwidthtimedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthtimedown.sh
  fi
  echo ">Running upload LOC speedtest"
  sh dospeedtestU.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCbandwidthupOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCbandwidthup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthup.sh
    m=$(sh /tmp/bsw/LOCbandwidthupif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthupif.sh
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbandwidthupif.sh
    m=$(sh /tmp/bsw/LOCbandwidthbyteup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthbyteup.sh
    m=$(sh /tmp/bsw/LOCbandwidthtimeup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCbandwidthtimeup.sh
  fi
fi
rm /tmp/bsw/INTband* >& /dev/null
d=$(uci get baking.speedtest_INT_server 2> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running download INT speedtest"
  sh dospeedtestD.sh INT 1 0
  c=$(sh /tmp/bsw/INTbandwidthdownOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTbandwidthdown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthdown.sh
    m=$(sh /tmp/bsw/INTbandwidthdownif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthdownif.sh
    echo "echo -$m" > /tmp/bsw/INTbandwidthbandwidthdownif.sh
    m=$(sh /tmp/bsw/INTbandwidthbytedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthbytedown.sh
    m=$(sh /tmp/bsw/INTbandwidthtimedown.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthtimedown.sh
  fi
  echo ">Running upload INT speedtest"
  sh dospeedtestU.sh INT 1 0
  c=$(sh /tmp/bsw/INTbandwidthupOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTbandwidthup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthup.sh
    m=$(sh /tmp/bsw/INTbandwidthupif.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthbandwidthupif.sh
    m=$(sh /tmp/bsw/INTbandwidthbyteup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthbyteup.sh
    m=$(sh /tmp/bsw/INTbandwidthtimeup.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTbandwidthtimeup.sh
  fi
fi
echo 2 > /tmp/led
rm /tmp/bsw/NACping* >& /dev/null
d=$(uci get baking.ping_NAC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping NAC"
  sh runping.sh NAC 1 0
  c=$(sh /tmp/bsw/NACpingOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/NACpingavg.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingavg.sh
    m=$(sh /tmp/bsw/NACpingmax.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingmax.sh
    m=$(sh /tmp/bsw/NACpingmin.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingmin.sh
    m=$(sh /tmp/bsw/NACpingstd.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingstd.sh
    m=$(sh /tmp/bsw/NACpingtimeouts.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/NACpingtimeouts.sh
    m=$(sh /tmp/bsw/NACpingICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/NACpingICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/NACpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/NACpingalive.sh)
    echo "echo -$m" > /tmp/bsw/NACpingalive.sh
  fi
fi
rm /tmp/bsw/INTping* >& /dev/null
d=$(uci get baking.ping_INT_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping INT"
  sh runping.sh INT 1 0
  c=$(sh /tmp/bsw/INTpingOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/INTpingavg.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingavg.sh
    m=$(sh /tmp/bsw/INTpingmax.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingmax.sh
    m=$(sh /tmp/bsw/INTpingmin.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingmin.sh
    m=$(sh /tmp/bsw/INTpingstd.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingstd.sh
    m=$(sh /tmp/bsw/INTpingtimeouts.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/INTpingtimeouts.sh
    m=$(sh /tmp/bsw/INTpingICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/INTpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/INTpingICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/INTpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/INTpingalive.sh)
    echo "echo -$m" > /tmp/bsw/INTpingalive.sh
  fi
fi
rm /tmp/bsw/LOCping* >& /dev/null
d=$(uci get baking.pingLOC_server 2&> /dev/null)
if [ $? -eq 0 ] ; then
  echo ">Running ping LOC"
  sh runping.sh LOC 1 0
  c=$(sh /tmp/bsw/LOCpingOK.sh)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/LOCpingavg.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingavg.sh
    m=$(sh /tmp/bsw/LOCpingmax.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingmax.sh
    m=$(sh /tmp/bsw/LOCpingmin.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingmin.sh
    m=$(sh /tmp/bsw/LOCpingstd.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingstd.sh
    m=$(sh /tmp/bsw/LOCpingtimeouts.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/LOCpingtimeouts.sh
    m=$(sh /tmp/bsw/LOCpingICMP_Echo_Replies_received.sh)
    echo "echo -$m" > /tmp/bsw/LOCpingICMP_Echo_Replies_received.sh
    m=$(sh /tmp/bsw/LOCpingICMP_Echos_sent.sh)
    echo "echo -$m" > /tmp/bsw/LOCpingICMP_Echos_sent.sh
    m=$(sh /tmp/bsw/LOCpingalive.sh)
    echo "echo -$m" > /tmp/bsw/LOCpingalive.sh
  fi
fi
echo 3 > /tmp/led
rm /tmp/bsw/ip* >& /dev/null
d=$(uci get baking.renew)
if [ $d -ne 0 ] ; then
  echo ">Running RENEW"
  sh runrenew.sh 
  c=$(sh /tmp/bsw/IPloginOK.sh 2>/dev/null)
  if [ $c -eq 0 ] ; then
    m=$(sh /tmp/bsw/IPloginrenew.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/IPloginrenew.sh
    m=$(sh /tmp/bsw/IPloginrenew_status.sh 2>/dev/null)
    echo "echo -$m" > /tmp/bsw/IPloginrenew_status.sh
  fi
fi
ps -fea | grep maxtemp  | grep -v grep | awk '{ print $2 }' | xargs kill -9 2>/dev/null > /dev/null
touch /tmp/maxtempin
touch /tmp/maxtempdatein
touch /tmp/maxtempout
touch /tmp/maxtempdateout

# TEMP IN
t=$(cat /tmp/tempin.log | sort | tail -1 | awk '{ print $1*1000 }')
tm=$(cat /tmp/maxtempin | awk '{ print $1*1000'} 2>/dev/null)
if [ "$tm" == "" ] ; then
  tm=0
fi
tt=$(cat /tmp/tempin.log | sort | tail -1)
if [ $tm -le $t ] ; then
  echo $tt > /tmp/maxtempin
  date > /tmp/maxtempdatein
fi
echo "echo $tt" > /tmp/bsw/IPlogintemperaturein.sh

# TEMP OUT
t=$(cat /tmp/tempout.log | sort | tail -1 | awk '{ print $1*1000 }')
tm=$(cat /tmp/maxtempout | awk '{ print $1*1000}' 2>/dev/null)
if [ "$tm" == "" ] ; then
  tm=0
fi
tt=$(cat /tmp/tempout.log | sort | tail -1)
if [ $tm -le $t ] ; then
  echo $tt > /tmp/maxtempout
  date > /tmp/maxtempdateout
fi
echo "echo $tt" > /tmp/bsw/IPlogintemperatureout.sh

ta=$(cat /tmp/tempand.log | sort | tail -1)
echo "echo $ta" > /tmp/bsw/IPlogintemperatureandroid.sh
tb=$(cat /tmp/tempbat.log | sort | tail -1)
echo "echo $tb" > /tmp/bsw/IPlogintemperaturebattery.sh

if [ "$iface" == "PHONE" ] ; then
  #Signal
  signal=$(adb shell dumpsys telephony.registry | grep mSignalStrength | awk '{print $2,$3,$4,$5,$6,$7,$8,$9}' | tr -dc '[[:print:]]')
  echo "echo $signal" > /tmp/bsw/IPloginsignal3G.sh
  #GPS
  lat=$(adb shell dumpsys location  | grep "gps: Location"  | tail -1 | awk '{ print $3 }' | awk 'BEGIN {FS=","}{if ($2 > 360) {print $1"."$2} else {print $1}}')
  lon=$(adb shell dumpsys location  | grep "gps: Location"  | tail -1 | awk '{ print $3 }' | awk 'BEGIN {FS=","}{if ($2 > 360) {print $3"."$4} else {print $2}}')
  alt=$(adb shell dumpsys location  | grep "gps: Location"  | tail -1 | awk '{ print substr($6,5) }')
  if [ "$lat" == "" ] ; then
    lat=$(adb shell dumpsys location  | grep "passive: Location"  | tail -1 | awk '{ print $3 }' | awk 'BEGIN {FS=","}{if ($2 > 360) {print $1"."$2} else {print $1}}')
    lon=$(adb shell dumpsys location  | grep "passive: Location"  | tail -1 | awk '{ print $3 }' | awk 'BEGIN {FS=","}{if ($2 > 360) {print $3"."$4} else {print $2}}')
  fi
  if [ "$lat" == "" ] ; then
    lat=$(adb shell dumpsys location | grep Cell | tail -1 | awk 'BEGIN {FS="latE7="}{print $3}' | awk 'BEGIN {FS=","}{printf "%3.8f",$1/10000000}')
    lon=$(adb shell dumpsys location | grep Cell | tail -1 | awk 'BEGIN {FS="lngE7="}{print $2}' | awk 'BEGIN {FS=","}{printf "%3.8f",$1/10000000}')
  fi
  if [ "$lat" != "" ] ; then
    echo "echo $lat" > /tmp/bsw/IPloginlat.sh
    echo "echo $lon" > /tmp/bsw/IPloginlon.sh
    if [ "$alt" != "" ] ; then
      echo "echo $alt" > /tmp/bsw/IPloginalt.sh
    fi
  fi
  #Batt
  bat=$(adb shell dumpsys battery | grep level | awk '{print $2}')
  echo "echo $bat" > /tmp/bsw/IPloginbat.sh

  #Network
  inet=$(adb shell dumpsys connectivity | grep "NetworkInfo: type: mobile" | grep -v none | awk '{print substr($3,8,length($3)-9)}')
  net=0
  if [ "$inet" == "1xRTT" ] ; then
    net=7
  fi
  if [ "$inet" == "CDMA" ] ; then
    net=4
  fi
  if [ "$inet" == "EDGE" ] ; then
    net=2
  fi
  if [ "$inet" == "eHRPD" ] ; then
    net=14
  fi
  if [ "$inet" == "EVDO rev. 0" ] ; then
    net=5
  fi
  if [ "$inet" == "EVDO rev. A" ] ; then
    net=6
  fi
  if [ "$inet" == "EVDO rev. B" ] ; then
    net=2
  fi
  if [ "$inet" == "GPRS" ] ; then
    net=1
  fi
  if [ "$inet" == "HSDPA" ] ; then
    net=8
  fi
  if [ "$inet" == "HSPA" ] ; then
    net=10
  fi
  if [ "$inet" == "HSPA+" ] ; then
    net=15
  fi
  if [ "$inet" == "HSUPA" ] ; then
    net=9
  fi
  if [ "$inet" == "iDen" ] ; then
    net=11
  fi
  if [ "$inet" == "LTE" ] ; then
    net=13
  fi
  if [ "$inet" == "UMS" ] ; then
    net=3
  fi

  echo "echo $net" > /tmp/bsw/IPloginnet.sh
fi
if [ "$iface" == "MF206A" ] ; then
  signal=$(sh ZTESignal.sh)
  echo "echo $signal" > /tmp/bsw/IPloginsignal3G.sh
fi
if [ "$iface" == "TL-MR3020" ] ; then
  signal=$(sh tplink.sh | grep Signal | awk '{print $3*1}')
  echo "echo $signal" > /tmp/bsw/IPloginsignal3G.sh
fi

cp /tmp/bsw/* /root/bsw >& /dev/null
sleep 5
sh trap.sh
echo 4 > /tmp/led
sh postvalue.sh

sh log.sh "dotests.sh: Test completed"
echo "" > /tmp/nextrun.txt
echo -4 > /tmp/led

