
nand=$(ps -fea | grep android | grep -v grep | wc -l)
if [ $nand -ne 2 ] ; then
  exit
fi
ip="0.0.0.0"
while [ 1 ] ;
do
  iface=$(uci get system.iface)
  if [ "$iface" == "PHONE" ] ; then
    pro=$(adb shell cat /system/build.prop | grep product.model | awk 'BEGIN {FS="="} {print $2}' | tr -dc '[[:print:]]')
    ad=$(ps -fea | grep fork-server | grep -v grep | wc -l)
    if [ $ad -eq 0 ] ; then
      echo "Starting ADB Server"
      adb start-server
    fi
    device=$( adb devices | grep -v List | head -1 | grep offline | wc -l)
    if [ $device -eq 1 ] ; then
      echo "Device Offline"
      adb kill-server 
      sleep 3
      adb start-server 
      sleep 3
    fi
    usb=$(ifconfig -a | grep usb0 | wc -l)
    if [ $usb -eq 1 ] ; then
      newip=$(ifconfig usb0 | grep "inet " | awk '{print $2}')
      if [ "$ip" != "$newip" ] ; then
  	echo "Device: $pro"
	echo "IP: $newip"
      fi
      ip=$newip
      data=$(adb shell dumpsys connectivity | grep Network | grep "mobile\[")
      echo $data
      data=$(adb shell dumpsys telephony.registry | grep mServiceState)
      echo $data
      data=$(adb shell dumpsys telephony.registry | grep mSignalStrength)
      echo $data
    else
      ip="0.0.0.0"
    fi
    device=$(adb devices | grep -v List | head -1 | grep device | wc -l)
    if [ $device -eq 0 ] ; then
	echo "No USB Phone connected"
    fi
    if [ $usb -eq 0 ] && [ $device -eq 1 ] ; then
      dev=$(adb devices | grep -v List | head -1 | grep device | awk '{ print $1 }')
      pro=$(adb shell cat /system/build.prop | grep product.model | awk 'BEGIN {FS="="} {print $2}' | tr -dc '[[:print:]]')
      echo "Conecting $pro"
      #sh /etc/config/phone/SM-A300YZ
      #sh /etc/config/phone/GT-S7580L
      sh /etc/config/phone/$pro
    fi
  fi
  ppp=$(ifconfig | grep ppp0 | wc -l)
  if [ $ppp -eq 0 ] ; then
     pppd call bsw
     route add -net 192.168.100.0 netmask 255.255.255.0 gw 192.168.100.14
  fi
  sleep 5
done
