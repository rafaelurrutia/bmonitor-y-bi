PATH=$PATH:/root
sh log.sh "pcontrol.sh"
echo ">Activating Parental Control"
lan=$(uci get network.lan.ipaddr)/$(uci get network.lan.netmask)
blockserver=$(nslookup $(echo $(uci get baking.server) | awk 'BEGIN {FS=":"}{print $1}') | tail -1 | grep Address | awk '{print $3}')
blockserverport=$(echo $(uci get baking.server) | awk 'BEGIN {FS=":"}{print $2}')
blockdns=$(nslookup block.opendns.com | tail -1 | grep Address | awk '{print $3}')
blockip1=$(ping -c 1 block.opendns.com | grep PING | awk 'BEGIN {FS="("}{print $2}' | awk 'BEGIN {FS=")"}{print $1}')
blockip2=$(ping -c 1 block.opendns.com | grep PING | awk 'BEGIN {FS="("}{print $2}' | awk 'BEGIN {FS=")"}{print $1}')
iptables -t nat -I prerouting_rule -i br-lan -s $lan -d  $blockip1/32 -p tcp --dport 80 -j DNAT --to $blockserver:$blockserverport 
iptables -t nat -I prerouting_rule -i br-lan -s $lan -d  $blockip2/32 -p tcp --dport 80 -j DNAT --to $blockserver:$blockserverport 
iptables -t nat -I prerouting_rule -i br-lan -s $lan -d  208.69.32.135/32 -p tcp --dport 80 -j DNAT --to $blockserver:$blockserverport 
iptables -t nat -I prerouting_rule -i br-lan -s $lan -d  67.215.65.130/32 -p tcp --dport 80 -j DNAT --to $blockserver:$blockserverport 
iptables -t nat -I prerouting_rule -i br-lan -s $lan -p udp --dport 53 -j DNAT --to $blockserver:53
iptables -t nat -I prerouting_rule -i br-lan -s $lan -p tcp --dport 53 -j DNAT --to $blockserver:53
echo "Activation complete to IP $blockip1 $blockip2"
