
modprobe w1-gpio
modprobe w1-gpio

> /tmp/tempin.log
> /tmp/tempout.log
> /tmp/tempand.log
> /tmp/tempbat.log


ok=0
dir=$(ls -1 /sys/bus/w1/devices |grep "28-" 2>/dev/null)
if [ "$dir" != "" ] ; then
 td=/sys/bus/w1/devices/$dir/w1_slave
 ok=1
fi

iface=$(uci get system.iface)

while [ 1 ] 
do
  vcgencmd measure_temp| egrep "[0-9.]{4,}" -o >> /tmp/tempin.log
  if [ $ok -eq 1 ] ; then
    out=$(cat $td  | grep "t=" | awk 'BEGIN {FS="="}{print int($2/100)/10}')
  else
    out=0
  fi
  echo $out >> /tmp/tempout.log
  if [ "$iface" == "PHONE" ] ; then
    cpu=$(adb shell cat /sys/class/thermal/thermal_zone0/temp | tr -dc '[[:print:]]')
    if [ "$cpu" == "" ] ; then
      cpu=$(adb shell  "cat /sys/devices/virtual/input/input1/temperature" | awk '{print $1/10}')
    fi
    bat=$(adb shell cat /sys/class/power_supply/battery/device/power_supply/battery/temp | awk '{print int($0/10)}' | tr -dc '[[:print:]]')  
    echo $cpu >> /tmp/tempand.log
    echo $bat >> /tmp/tempbat.log 
  fi
  sleep 1
done


