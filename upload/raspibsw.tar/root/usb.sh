./hub-ctrl -P 2 -p 0
sleep 5
./hub-ctrl -P 2 -p 1
sleep 45


