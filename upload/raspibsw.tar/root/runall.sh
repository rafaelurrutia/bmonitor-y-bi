# Baking Software 2012
# VERSION=26.03.2013.a
PATH=$PATH:/root

cd /root
(gpio mode 0 out; gpio write 0 1; sleep 0.005;gpio write 0 0)
sleep 1
(gpio mode 0 out; gpio write 0 1; sleep 0.005;gpio write 0 0)

mkdir /var/mem 2> /dev/null
clear
echo $(date) ">Stopping Applications"
sh httppage.sh
ps -fea | grep led.sh | grep -v grep | awk '{system("kill -9 " $2)'}
echo 0 > /tmp/led
sh led.sh 2>&1 > /dev/null &
ps -fea | grep bswloop.sh | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep curl.sh | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep bswcheck.sh | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep sleep | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep curl | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep ifstat | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep ZTECheck | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep ZTEConnect | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep ZTERegister | grep -v grep | awk '{system("kill -9 " $2)'}
ps -fea | grep android | grep -v grep | awk '{system("kill -9 " $2)'}

#ifconfig eth0:1 192.168.50.1 netmask 255.255.255.0
sh android.sh 2>&1 > /dev/null &

#tplink=$(netstat -anr | grep "192.168.0.254" | wc -l)
#if [ $tplink -eq 1 ] ; then
#  uci set system.iface=TL-MR3020
#fi

iface=$(uci get system.iface)
if [ "$iface" == "" ] ; then
  uci set system.iface="eth0"
  iface=eth0
fi
echo $(date) "System Model Interface $iface"
if [ "$iface" == "PHONE" ] ; then
  sh android.sh &
fi
if [ "$iface" == "MF206A" ] ; then
  echo $(date) "Check MF206A"
  sh ZTECheck.sh &
fi
if [ -f /etc/banner ] ; then
  cat /etc/banner
else
  if [ -s banner ] ; then
    cat banner
  fi
fi

echo $(date) ">Initializing system"
echo "Booting" > /tmp/nextrun.txt
rm -f /tmp/config.sh
touch /tmp/tempin.log
touch /tmp/tempout.log
touch /tmp/maxtempdatain
touch /tmp/maxtempdataout
touch /tmp/maxtempin
touch /tmp/maxtempout
touch /tmp/testduration
touch /tmp/panic
touch lastboot
touch /tmp/lastalive
touch /tmp/lastconfig
touch /tmp/status
cp -f /etc/config/* /var/mem
cd /root
sh httppage.sh
echo -3 > /tmp/led
mkdir /tmp/bsw >& /dev/null
mkdir /root/bsw >& /dev/null
mksir /etc/gcom 2>/dev/null
sh clean.sh
dns=$(grep Configuration /etc/dnsmasq.conf | wc -l)
if [ $dns -eq 0 ] ; then
  echo address=\"\/router.lan\/$(uci get network.lan.ipaddr)\" > /etc/dnsmasq.conf
  /etc/init.d/dnsmasq reload
fi
uci set system.bswkeepalive=0

echo "Starting. Check Internet" >/tmp/status
sh log.sh "runall.sh: Starting router"
if [ -f /etc/init.d/uhttpd ] ; then
  /etc/init.d/uhttpd restart
else
  service httpd restart
fi
ps -fea | grep http.sh | grep -v grep | awk '{system("kill -9 " $1)'}
sh http.sh 2>&1 > /dev/null &
sh httppage.sh
sh firewall.sh
echo "BSW System Boot" >/tmp/status
sh httppage.sh
if [ "$1" != "fast" ] ; then
  echo "BSW System Boot: Delaying 60 seconds" >/tmp/status
  echo $(date) ">Sleeping 120 seconds to allow login"
  sleep 60
  sleep 60
  sleep 60
  sleep 60
fi
# Check for internet
sh checkinternet.sh
echo $(date) "> Syncronizing time"
ntp=$(type ntpdate 2>/dev/null | wc -l)
if [ $ntp -eq 1 ] ; then
  ntpdate -s pool.ntp.org
else
  rdate=$(type rdate | awk '{ print $3}')
  $rdate -s nist1.symmetricom.com
fi
sh httppage.sh

if [ -s /proc/kcore ] ; then
  uci set baking.kcore="@/proc/kcore"
else
  dd if=/dev/zero of=/tmp/kcore bs=3000000 count=2
  uci set baking.kcore="@/tmp/kcore"
fi

# sh setup.sh
if [ "$1" != "RESTORE" ] ; then
  sh poweroff.sh &
  dd=$(date +"%s")
  echo $dd > lastboot
fi
if [ ! -e lastboot ] ; then
  dd=$(date +"%s")
  echo $dd > lastboot
fi
#sh quote.sh
sh log.sh "Clean ITEM"
echo "Clean ITEM" >/tmp/status
uci show baking | grep ITEM | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null
uci show baking | grep speedtest_ | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null
uci show baking | grep ping_ | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null
echo "Starting. Stopping Running Applications" > /tmp/status

uci set baking.start=$(date +"%s")
uci set baking.stop=$(date +"%s")


f=$(uci show firewall | grep dest_port=1161 | wc -l)
if [ $f -eq 0 ] ; then
  echo $(date) ">Add 1161 to firewall"
  uci add firewall rule              
  uci set firewall.@rule[-1].src=wan
  uci set firewall.@rule[-1].target=ACCEPT
  uci set firewall.@rule[-1].proto=udp
  uci set firewall.@rule[-1].dest_port=1161
  uci firewall commit 
  sh firewall.sh
fi
if [ -f /etc/snmp/snmpd.conf ] ; then
  sp=$(grep agentaddress /etc/snmp/snmpd.conf | wc -l)
  if [ $sp -eq 0 ] ; then
    echo "agentaddress :1161" >> /etc/snmp/snmpd.conf
  fi
fi
sh httppage.sh
uci set snmpd.@system[0].sysName=$(sh getmac.sh  | awk '{ gsub(":",""); print "BSW" $1}')
uci set system.bswkeepalive=0

echo $(date) ">Restarting SNMP"
echo $(date) ">Restarting cron"
if [ -f /etc/init.d/cron ] ; then
  /etc/init.d/snmpd restart
  /etc/init.d/cron restart
else
  service crond restart
  service snmpd restart
fi

rm /etc/config/ntpclient 2> /dev/null
killall ntpclient 2> /dev/null          
sh httppage.sh

echo "Staring BSW Applications" > /tmp/status
echo $(date) ">Starting BSW Applications"
sh httppage.sh
cp /root/bsw/* /tmp/bsw 2> /dev/null
rm /tmp/config.sh 2> /dev/null
pc=$(uci get baking.pcontrol)                                                                           
if [ "$pc" == "1" ] ; then                                                                            
  sh pcontrol.sh                                                                                        
fi                                                                                                      
sh bswcheck.sh 2>&1 > /dev/null &
sh bswloop.sh 2>&1 > /dev/null &
echo $(date) "Operational" > /tmp/status
sh log.sh "runall.sh: Completed"
echo $(date) ">Initialization Complete"
sh httppage.sh
echo ""

echo -4 > /tmp/led
sh temperature.sh
sh temperature.sh
(gpio mode 0 out; gpio write 0 1; sleep 0.005;gpio write 0 0)
sleep 1
(gpio mode 0 out; gpio write 0 1; sleep 0.005;gpio write 0 0)
sleep 1
(gpio mode 0 out; gpio write 0 1; sleep 0.005;gpio write 0 0)

