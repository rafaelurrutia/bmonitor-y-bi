
while [ 1 ] ; do
  iface=eth0
  usb0=$(ifconfig | grep usb0 | wc -l)
  eth0=$(ifconfig | grep eth0 | wc -l)
 eth1=$(ifconfig | grep eth1 | wc -l)

  if [ $usb0 -eq 1 ] ; then
    usb0=$(ifconfig usb0 | grep "inet " | wc -l)
  fi
 if [ $eth0 -eq 1 ] ; then
    eth0=$(ifconfig eth0 | grep "inet " | wc -l)
  fi

  if [ $eth1 -eq 1 ] ; then
    eth1=$(ifconfig eth1 | grep "inet " | wc -l)
  fi
  if [ $eth0 -eq 1 ] ; then
    iface="eth0"
  fi
  if [ $eth1 -eq 1 ] ; then
    iface="eth1"
  fi
  if [ $usb0 -eq 1 ] ; then
   iface="usb0"
  fi
  # echo $iface
  def=$(cat $(ls -1 /var/lib/NetworkManager/*$iface.lease | grep "dhclient-" | tail -1) | grep routers | tail -1 | awk '{print substr($3,1,length($3)-1)}')
rt=$(netstat -nr | grep "^0.0.0.0" | awk '{print $2}')
  if [ "$def" == "eth0" ] && [ "$rt" == "" ] ; then
    echo "Restarting network Service"
    service network restart 
    route -an
  fi
  if [ "$rt" != "$def" ] && [ "$def" != "" ] && [ "$iface" != "eth0" ] ; then
    echo "gw: actual=$rt default=$def"
    echo "Add $def"
    while [ "$rt" != "" ]
    do 
      route delete default 
      rt=$(netstat -nr | grep "^0.0.0.0" | awk '{print $2}')
    done
    route add default gw $def
    netstat -nr
  fi

  sleep 5
done
