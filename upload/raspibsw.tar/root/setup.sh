yum update
yum install net-tools fping httpd.armv6hl php ifstat net-snmp net-snmp-utils net-snmp-sysvinit
crontab cron
