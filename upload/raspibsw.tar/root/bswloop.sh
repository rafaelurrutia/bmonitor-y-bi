export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin:/root

t=$(uci get baking.delay 2>/dev/null)
if [ "$t" == "" ] ; then
  sh log.sh"ERROR: system.delay"
fi
if [ "$t" != "0" ] ; then 
  s=$(uci get system.bswslot 2>/dev/null)
  if [ "$s" == "" ] ; then
    r=$(echo $t | awk  '{ srand();x=int(rand()*100 % ($1/60)); print x; }')
    uci set system.bswslot=$r
    
  else
    r=$(uci get system.bswslot)
  fi
else
  uci set system.bswslot=0
  
  r=0
fi
cp /root/bsw/* /tmp/bsw 2>/dev/null
uci set baking.ISLAST=NO
while [ 1 ]
do
  r=$(uci get system.bswslot)
  echo "Operational. Idle" > /tmp/status

  OK="NO"
  while [ "$OK" == "NO" ] ; do
    OK=$(sh cdate.sh $(uci get baking.horario))
    if [ "$OK" == "NO" ] ; then
      echo "Waiting for time " $(uci get baking.horario) > /tmp/nextrun.txt
      sleep 5
    fi
  done
  mm=$(date +"%M" | awk '{ print $1*1 }')
  suma=0
  if [ $mm -ge $r ] ; then
    suma=$(uci get baking.delay)
  fi
  dd=$(date +"%s" | awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')
  nr=$(echo $t $(date +"%s") $r $suma| awk '{ print strftime("%d/%m/%Y %H:%M:%S",$2 - $2 % $1 + $4 + $3*60)}')
  if [ "$t" != "0" ] ; then
    d=$(date +"%M" | awk -v t=$t '{ print $1 % (t/60) }')
    while [ "$d" != "$r" ]
    do
      echo "Operational. Idle" > /tmp/status
      sleep 5
      mm=$(date +"%M" | awk '{ print $1*1 }')
      suma=0
      if [ $mm -gt $r ] ; then
        suma=$(uci get baking.delay)
      fi
      r=$(uci get system.bswslot)
      t=$(uci get baking.delay)
      OK1=$(sh cdate.sh $(uci get baking.horario))
      OK2=$(sh cdate.sh $(uci get baking.horario) +1 )
      ISLAST=$(uci get baking.ISLAST)
      HALF="NO"
      
      dt=$(date +"%s")
      vac1=$(uci get baking.ndw1 2&> /dev/null)
      vac2=$(uci get baking.ndw2 2&> /dev/null)
      VACATIONS="NO"
      if [ "$vac1" != "" ] ; then                    
        if [ $dt -gt $vac1 ] && [ $dt -lt $vac2 ] ; then                
            echo "Tests in pause. Router state is in vacations" > /tmp/nextrun.txt
            d=-1
            VACATIONS="YES"
        fi                                           
      fi     
      
      if [ "$VACATIONS" == "NO" ] ; then 
        if [ $r -ge 30 ] && [ $mm -le 30 ] ; then
          if [ "$OK1" == "OK" ] && [ "$OK2" == "NO" ] ; then
            d=$(date +"%M" | awk -v t=$t '{ print $1 % (t/60) }')
            r=$(echo $r | awk '{ print int($1/2) }')
            nr=$(echo $t $(date +"%s") $r $suma| awk '{ print strftime("%d/%m/%Y %H:%M:%S",$2-$2 % $1+$3*60 + $4)}')
            echo "$nr [$d $r]" > /tmp/nextrun.txt
            HALF="YES"
          fi
        fi
        if [ "$HALF" == "NO" ] ; then
          if [ "$OK1" == "NO" ] ; then
            echo "Waiting for time " $(uci get baking.horario) > /tmp/nextrun.txt
          else
            d=$(date +"%M" | awk -v t=$t '{ print $1 % (t/60) }')
            nr=$(echo $t $(date +"%s") $r $suma| awk '{ print strftime("%d/%m/%Y %H:%M:%S",$2 - $2 % $1 + $4 + $3*60)}')
            echo "$nr [$d $r]" > /tmp/nextrun.txt
          fi
        fi
      fi
    done
  fi
  while [ ! -s /tmp/config.sh ]
  do
    echo "Operational. Waiting for Config File" > /tmp/status
    sleep 5
  done
  ISLAST="NO"
  OK1=$(sh cdate.sh $(uci get baking.horario))
  OK2=$(sh cdate.sh $(uci get baking.horario) +1 )
  if [ "$OK1" == "OK" ] && [ "$OK2" == "NO" ] && [ $r -ge 30 ] ; then
    uci set baking.ISLAST=YES
  fi
  if [ "$OK1" == "OK" ] ; then
    echo "$nr => Working now" > /tmp/nextrun.txt
    uci set baking.start=$(date +"%s")
    uci set baking.stop=$(date +"%s")
    
    sh dotests.sh 
    w=$(uci get system.bswkeepalive)
    if [ $w -eq 0 ] ; then
      sh keepalive.sh
    fi
    uci set baking.stop=$(date +"%s")
    
    echo $(uci get baking.stop) $(uci get baking.start) | awk '{ s=$1-$2;h=int(s/3600);s=s-(h*3600);m=int(s/60);s=s-(m*60);printf("%d:%02d:%02d\n", h, m, s);}' > /tmp/testduration
    dt=$(echo $(uci get baking.stop) $(uci get baking.start) | awk '{ print $1-$2}')
    echo "echo $dt" > /tmp/bsw/DurationOfTheTest.sh
  fi
done

