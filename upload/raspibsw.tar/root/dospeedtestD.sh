export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin:/root

sh log.sh "dospeedtestD.sh: $1"
s=$(uci get baking.speedtest_$1_server)
R=$(uci get baking.retry)

if [ $2 -eq 1 ] ; then
  uci set baking.TestRetry=1
  
fi

t=$(uci get baking.speedtest_$1_time_B)
if [ $t -eq 0 ] ; then
  exit
fi
N=$(uci get baking.speedtest_$1_sessions_B)
if [ $N -eq 0 ] ; then
  exit
fi
echo "Operational. Performing Test Download $1" > /tmp/status

dn=$(uci get baking.speedtest_$1_download_path)
up=$(uci get baking.speedtest_$1_upload_path)
t=$(uci get baking.TestRetry)
sh runcurlD.sh $s $dn $up $1 $t

val=$(sh /tmp/$t/$1bandwidthdown.sh)
gr=$(uci get baking.groupname)
if [ "$gr" == "FDT" ] ; then
  val=$(sh /tmp/$t/$1bandwidthdownif.sh)
else
  val=$(sh /tmp/$t/$1bandwidthdown.sh)
fi
if [ "$val" == "" ] ; then
  val=0
fi
min=$(uci get baking.$1_D)                                                                 
let min=$min*1024        
if [ $val -ge $min ] ; then
  echo "SPEED $1 Down Try $t [$val bps] OK"
  sh cumple.sh $1 D $t
  echo "echo 1" > /tmp/$t/$1bandwidthdownspeedOK.sh
  cp /tmp/$t/* /tmp/bsw
  rm -rf /tmp/1 &> /dev/null
  rm -rf /tmp/2 &> /dev/null
  rm -rf /tmp/3 &> /dev/null
else
  if [ $t -eq $R ] ; then
    val1=$(sh /tmp/1/$1bandwidthdown.sh)
    val2=$(sh /tmp/2/$1bandwidthdown.sh)
    val3=$(sh /tmp/3/$1bandwidthdown.sh)
    if [ $val1 -ge $val2 ] ; then
      if [ $val1 -ge $val3 ] ; then
	#echo "SPEED $1 Down Try $t [$val bps] BEST 1=>[$val1 bps]"
	sh cumple.sh $1 D 1
        echo "echo 0" > /tmp/1/$1bandwidthdownspeedOK.sh
        if [ $val1 -ne 0 ]; then
          cp /tmp/1/* /tmp/bsw
        fi
      fi
    fi
    if [ $val2 -ge $val1 ] ; then
      if [ $val2 -ge $val3 ] ; then
	#echo "SPEED $1 Down Try $t [$val bps] BEST 2=>[$val2 bps]"
	sh cumple.sh $1 D 2
        echo "echo 0" > /tmp/2/$1bandwidthdownspeedOK.sh
        if [ $val2 -ne 0 ] ; then
          cp /tmp/2/* /tmp/bsw
        fi
      fi
    fi
    if [ $val3 -ge $val1 ] ; then
      if [ $val3 -ge $val2 ] ; then
	#echo "SPEED $1 Down Try $t [$val bps] BEST 3=>[$val3 bps]"
	sh cumple.sh $1 D 3
        echo "echo 0" > /tmp/3/$1bandwidthdownspeedOK.sh
        if [ $val3 -ne 0 ] ; then
          cp /tmp/3/* /tmp/bsw
        fi
      fi
    fi
    rm -rf /tmp/1 &> /dev/null
    rm -rf /tmp/2 &> /dev/null
    rm -rf /tmp/3 &> /dev/null
  else
    echo "SPEED $1 Down try $t [$val bps]"
    let t=$t+1
    uci set baking.TestRetry=$t
    
    if [ $val -le $3 ] ; then
      sh dospeedtestD.sh $1 2 $3
    else
      sh dospeedtestD.sh $1 2 $val
    fi  
  fi
fi

