<?php
//prevents caching
header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: post-check=0, pre-check=0",false);
//session_cache_limiter();
//session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<script language="javascript">
function change_connectiontype() {
	document.basic.action = 'basic.php'; 
	document.basic.submit();
}
function my_submit() {
	document.basic.submit();
}
</script>
</head>
<body>
<?php
if ($_POST['connectiontype'] == null || $_POST['connectiontype'] == "") {
	$connectiontype = exec('uci get network.wan.proto');
	if ($connectiontype == 'dhcp') {
		$seldhcp = "selected";
		$selpppoe = "";
		$selstatic = "";
		$sel3G = "";
	} elseif ($connectiontype == 'pppoe') {
		$seldhcp = "";
		$selpppoe = "selected";
		$selstatic = "";
		$sel3G = "";
		$username = exec('uci get network.wan.username');
		$password = exec('uci get network.wan.password');
	}  elseif ($connectiontype == 'static') {
		$seldhcp = "";
		$selpppoe = "";
		$selstatic = "selected";
		$sel3G = "";
		$ipaddr = exec('uci get network.wan.ipaddr');
		$netmask = exec('uci get network.wan.netmask');
		$gateway = exec('uci get network.wan.gateway');
		$dns = exec('uci get network.wan.dns');
		$exploded_dns = explode(' ', $dns);
	}  elseif ($connectiontype == '3g') {
		$seldhcp = "";
		$selpppoe = "";
		$selstatic = "";
		$sel3G = "selected";
		$apn3g = exec('uci get network.wan.apn');
		$username3g = exec('uci get network.wan.username');
		$password3g = exec('uci get network.wan.password');
		$pin3g = exec('uci get network.wan.pincode');
	}
} elseif ($_POST['connectiontype'] == 'pppoe') {
	$seldhcp = "";
	$selpppoe = "selected";
	$selstatic = "";
	$sel3G = "";
	if ( exec('uci get network.wan.proto')==$_POST['connectiontype'] ) {
		$username = exec('uci get network.wan.username');
		$password = exec('uci get network.wan.password');
	}
} elseif ($_POST['connectiontype'] == 'static') {
	$seldhcp = "";
	$selpppoe = "";
	$selstatic = "selected";
	$sel3G ="";
	if ( exec('uci get network.wan.proto')==$_POST['connectiontype'] ) {
		$ipaddr = exec('uci get network.wan.ipaddr');
		$netmask = exec('uci get network.wan.netmask');
		$gateway = exec('uci get network.wan.gateway');
		$dns = exec('uci get network.wan.dns');
		$exploded_dns = explode(' ', $dns);
	}
} elseif ($_POST['connectiontype'] == 'dhcp') {
	$seldhcp = "selected";
	$selpppoe = "";
	$selstatic = "";
	$sel3G = "";
} elseif ($_POST['connectiontype'] == '3g') {
	$seldhcp = "";
	$selpppoe = "";
	$selstatic = "";
	$sel3G = "selected";
	if ( exec('uci get network.wan.proto')==$_POST['connectiontype'] ) {
		$apn3g = exec('uci get network.wan.apn');
		$username3g = exec('uci get network.wan.username');
		$password3g = exec('uci get network.wan.password');
		$pin3g = exec('uci get network.wan.pincode');
	}
}
?>
<form action="basic-proc.php" method="post" name="basic">
	<fieldset>
    <legend>Basic Settings</legend>
    <table width="800" border="0">
      <tr>
        <td width="175">Connection Type</td>
        <td width="283"><select name="connectiontype" onChange="change_connectiontype();">
          <option <?php echo $seldhcp; ?> value="dhcp">Automatic DHCP</option>
          <option <?php echo $sel3G; ?> value="3g">BAM</option>
	  <option <?php echo $selpppoe; ?> value="pppoe">PPPoE</option>
          <option <?php echo $selstatic; ?> value="static">Static IP</option>
        </select></td>
        <td width="328">&nbsp;</td>
      </tr>

		<?php
		if ($sel3G == "selected") {
		echo '<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; APN</td><td><label><input type="text" name="apn3g" id="apn3g" value="'.$apn3g.'" /></label></td><td>&nbsp;</td></tr>';
		echo '<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; User Name</td><td><label><input type="text" name="username3g" id="username3g" value="'.$username3g.'" /></label></td><td>&nbsp;</td></tr>';
		echo '<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Password</td><td><label><input type="text" name="password3g" id="password3g" value="'.$password3g.'" /></label></td><td>&nbsp;</td></tr>';
		echo '<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PIN Code</td><td><label><input type="text" name="pin3g" id="pin3g" value="'.$pin3g.'" /></label></td><td>&nbsp;</td></tr>';
		exec('uci show dongles | grep model | sed -n \'s/.*\[\([^ ]*\)\].*/\1/p\'',$num);
		echo '<tr><td>Marca y modelo</td><td><label><select name="dongle">';

		foreach ($num as $i) {
			$vendor = exec('uci get dongles.@dongle['.$i.'].brand');
			$product = exec('uci get dongles.@dongle['.$i.'].model');
			echo '<option value="'.$product.'" ';
			if ( exec('uci get dongles.current.model')==$product ) { echo "selected"; }
			echo ' >'.$vendor.' - '.$product.'</option>';
		}
		echo '</select></label></td><td>&nbsp;</td></tr>';
	}
		if ($selpppoe == "selected") {
			echo '<tr><td>User Name</td><td><label><input type="text" name="username" id="username" value="'.$username.'" /></label></td><td>&nbsp;</td></tr>';
			echo '<tr><td>Password</td><td><label><input type="text" name="password" id="password" value="'.$password.'" /></label></td><td>&nbsp;</td></tr>';
		}
		if ($selstatic == "selected") {
			echo '<tr><td>WAN IP Address</td><td><label><input type="text" name="ipaddr" id="ipaddr" value="'.$ipaddr.'" /></label></td><td>&nbsp;</td></tr>';
      		echo '<tr><td>Subnet Mask</td><td><label><input type="text" name="netmask" id="netmask" value="'.$netmask.'" /></label></td><td>&nbsp;</td></tr>';
			echo '<tr><td>Gateway</td><td><label><input type="text" name="gateway" id="gateway" value="'.$gateway.'" /></label></td><td>&nbsp;</td></tr>';
			echo '<tr><td>Static DNS 1</td><td><label><input type="text" name="dns1" id="dns1" value="'.$exploded_dns[0].'" /></label></td><td>&nbsp;</td></tr>';
			echo '<tr><td>Static DNS 2</td><td><label><input type="text" name="dns2" id="dns2" value="'.$exploded_dns[1].'" /></label></td><td>&nbsp;</td></tr>';
		}
		?>
    </table>
  </fieldset>
  <p align="center">
    <input name="button" type="button" id="button" onclick="my_submit()" value="Apply" />
  </p>
</form>
<p>&nbsp;</p>
</body>
</html>
