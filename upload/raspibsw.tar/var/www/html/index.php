<?php
//ini_set('date.timezone', 'Etc/GMT+4.3');

exec("uci get baking.server1", $SVR1);
$SVR1 = $SVR1[0];
exec("uci get baking.server2", $SVR2);
$SVR2 = $SVR2[0];
exec("uci get baking.server", $SVR);
$SVR = $SVR[0];

exec("cat /proc/cpuinfo | grep 'model name' | awk 'BEGIN { FS=\":\"} { print substr($2,2,5) }'", $COM);
$COM = $COM[0];
exec("cat /proc/cpuinfo | grep 'Hardware' | awk 'BEGIN { FS=\":\"} { print substr($2,2) }'", $ROU);
$ROU = $ROU[0];
exec("cat /proc/cpuinfo | grep 'Serial' | awk 'BEGIN { FS=\":\"} { print substr($2,2) }'", $BOA);
$BOA = $BOA[0];

$nextrun = '';
$nextrun = exec("uci get baking.nextrun | awk '{print strftime(\"%d/%m/%Y %T\", $1)}'");

$ttime = exec('awk -v time=$(uci get baking.testduration 2> /dev/null) \'BEGIN {{print strftime("%H:%M:%S",(int(strftime("%z")/100 )*(-1)*3600)+(strftime("%z")%100*(-1)*60)+time)}}\'');
$tdate = exec('uci get baking.teststart 2> /dev/null | awk \'{ print strftime("%d/%m/%Y %T", $1)}\'');
$ttime = "$ttime @ $tdate";


if (is_readable("/root/status")) {
	$st = fopen("/root/status", "r");
	$st = @fread($st, filesize("/root/status"));
} else {
	$st = '';
}

exec("sh /root/getmac.sh", $mac);
$mac = $mac[0];
exec("uci get baking.pcontrol 2&> /dev/null", $par);
$par = $par[0];
exec("hostname", $hos);
$hos = $hos[0];
exec("sh /root/publicip.sh", $ip);
$ip = $ip[0];
exec("sh /root/getip.sh", $lio);
$lio = $lio[0];

if("$par" == "1") {
	$par = "Enabled";
}else {
	$par="Disabled";
}

exec("uci get system.version", $ver);
$ver = $ver[0];

exec("cat /root/lastboot| awk '{ print strftime(\"%d/%m/%Y %H:%M:%S\",$1)}'", $lastboot);
$lastboot = $lastboot[0];

exec("date '+%d/%m/%Y %T'", $d);
$d = $d[0];

exec("uptime", $uptime);
$uptime = $uptime[0];

exec("uname -a", $uname);
$uname = $uname[0];

$vacation = "";
$vac1 = exec('uci get baking.ndw1 2&> /dev/null');
$vac2 = exec('uci get baking.ndw2 2&> /dev/null');
if ( "$vac1" != "" ) {
	$ddt = exec('date +"%s"');
	if ( $vac2 > $ddt ) {
		$v1 = exec("echo $vac1 | awk '{ print strftime(\"%d/%m/%Y\",$1+3600*3)}'");
		$v2 = exec("echo $vac2 | awk '{ print strftime(\"%d/%m/%Y\",$1-3600*3)}'");
		$vacation = "$v1 - $v2";
	}
} else {
	$vacation = "N/A";
}


exec("uci get baking.horario 2&> /dev/null", $working);
$working = $working[0];

exec("uci get baking.plan 2&> /dev/null", $plan);
$plan = $plan[0];

exec("uci get baking.delay 2&> /dev/null", $delay);
$delay = $delay[0];

exec("uci get wireless.radio0.disabled 2&> /dev/null", $wf);
$wf = $wf[0];

exec("uci get baking.feriados 2&> /dev/null", $nwd);
$nwd = $nwd[0];

if ( "$nwd" == "" ) {
	$nwd = "N/A";
}

if($wf == 1) {
	$wf = "Disabled";
}else {
	$wf = "Enabled";
}


if (is_readable("/tmp/config.sh")) {
	$dt = fopen("/root/lastconfig", "r");
	$dt = fread($dt, filesize("/root/lastconfig"));
	$conf="Yes [$dt]";
} else {
	$conf="No";
	$plan="";
	$delay="";
	$working="";
	$state="Idle";
}


exec("uci show system | grep status | wc -l", $x);
$x = $x[0];

if( $x == 1) {
	exec("uci get system.status", $xst);
	$xst = $xst[0];
	if($xst == 1) {
    	$st="Router disabled on server";
    	$ttime="00:00:00";
	}
}
 
# recupera intensidad de señan 3g.

exec("uci get dongle.current.status", $statusport);
$statusport = $statusport[0];

exec("gcom -d /dev/$statusport sig | cut -f3 -d' ' | cut -f1 -d','", $sstrength);
$sstrength = $sstrength[0];

if($sstrength == 'device') {
	$sstrength = 'N/A';
}

if ( isset($_POST['selcombo']) ) {
	$interval = $_POST['selcombo'];
	setcookie("bProbeRefreshInterval", $interval);
} else {
	if ( isset($_COOKIE['bProbeRefreshInterval']) ){
		$interval = $_COOKIE['bProbeRefreshInterval'];
	} else {
		$interval = 5;
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta http-equiv="refresh" content="<?php echo $interval; ?>" />                        
<meta http-equiv="PRAGMA" content="NO-CACHE" />                      
<meta http-equiv="EXPIRES" content="-1" />   
<title>::Baking Sofware - bFirmware - 2012</title>
<link rel="stylesheet" type="text/css" href="index.css" />
</head>
<body>
	
<table>
	<div class="logo"><a href="http://www.bsw.cl"><img src="logo.jpg" width="300" height="71" alt="BakingSoftware" /></a>
	<div style="position:absolute; top:30px; right:0px; color:#000000; ">
	<form name="interval" action="index.php" method="post">
	Refresh interval: 
	<select name="selcombo" size=1 onchange="javascript:document.forms['interval'].submit();"> 
		<option <?php if ( $interval == 1 ) { echo "selected"; } ?> value="1">1 sec.</option>
		<option <?php if ( $interval == 5 ) { echo "selected"; } ?> value="5">5 sec.</option>
		<option <?php if ( $interval == 10 ) { echo "selected"; } ?> value="10">10 sec.</option>
		<option <?php if ( $interval == 15 ) { echo "selected"; } ?> value="15">15 sec.</option>
	</select>
	</form>
	</div>
	</div>
	<thead>
 	<tr class="odd">
		<th colspan="2" scope="row" class="column1"> Router time: <?php echo exec('date \'+%d/%m/%Y %T\'') ?></th>
	</tr>	
	<tr class="odd">
		<td class="column1"></td>
		<th scope="col" abbr="Home">Settings</th>
	</tr>	
	</thead>
	<tbody>
 	<tr>
		<th scope="row" class="column1"><big>Router</big></th>
		<td><big><?php echo $hos ?><big></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">MAC</th>
		<td><?php echo $mac ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Plan</th>	
		<td><?php echo $plan ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Public IP</th>
		<td><?php echo $ip ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Local IP</th>
		<td><?php echo $lio ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Version</th>
		<td><?php echo $ver ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Board</th>
		<td><?php echo $BOA ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Machine</th>
		<td><?php echo $ROU ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Model</th>
		<td><?php echo $COM ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">WiFi</th>
		<td><?php echo $wf ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Parental Control</th>
		<td><?php echo $par ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Config File</th>
		<td><?php echo $conf ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Active Server</th>
		<td><?php echo $SVR ?></td>
	</tr>
 	<tr class="odd">
		<th scope="row" class="column1">Server 1</th>
		<td><?php echo $SVR1 ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Server 2</th>
		<td><?php echo $SVR2 ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1"><b>Status</b></th>
		<td><b><?php echo $st ?></b></td></b>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Next run</th>
		<td><?php echo $nextrun ?></td>
	</tr>
 	<tr class="odd">
		<th scope="row" class="column1">Run every</th>
		<td><?php echo $delay." seconds" ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Working hours</th>
		<td><?php echo $working ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Vacations</th>
		<td><?php echo $vacation ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Hollidays</th>
		<td><?php echo $nwd ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Last update</th>
		<td><?php echo $d ?></td>
	</tr>
 	<tr>
		<th scope="row" class="column1">Test duration</th>
		<td><?php echo $ttime ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">System</th>
		<td><?php echo $uname ?></td>
	</tr>	
 	<tr>
		<th scope="row" class="column1">Uptime</th>
		<td><?php echo $uptime ?></td>
	</tr>	
 	<tr class="odd">
		<th scope="row" class="column1">Last Boot</th>
		<td><?php echo $lastboot ?></td>
	</tr>
 	<tr>
		<th scope="row" class="column1">Signal Strength</th>
		<td><?php echo $sstrength ?></td>
	</tr>	
	</tbody>
</table>
</body>
</html>

