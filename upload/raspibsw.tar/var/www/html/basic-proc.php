CTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<script language="javascript">
	cont=90;
	setTimeout(
		function(){
			window.location.href="basic.php";
		},90000);

	setInterval(
		function(){
			cont=cont-1;
			document.getElementById('cont').innerHTML=cont;
		},1000);			
</script>


<?php
#header("refresh:90;url=basic.php");

echo 'Wait <span id="cont">90</span> seconds. If the conection to the router is lost, reconnect and <a href="basic.php" >click here</a>.<br>';

$connectiontype = $_POST['connectiontype'];
$username = $_POST['username'];
$password = $_POST['password'];
$ipaddr = $_POST['ipaddr'];
$netmask = $_POST['netmask'];
$gateway = $_POST['gateway'];
$dns = "'".$_POST["dns1"]." ".$_POST["dns2"]." ".$_POST["dns3"]."'";

$apn3g = $_POST['apn3g'];
$username3g = $_POST['username3g'];
$password3g = $_POST['password3g'];
$pin3g = $_POST['pin3g'];
$dongle = $_POST['dongle'];

$num = exec('uci show dongles | grep '.$dongle.' | sed -n \'s/.*\[\([^ ]*\)\].*/\1/p\'');

$brand = exec('uci get dongles.@dongle['.$num.'].brand');
$model = exec('uci get dongles.@dongle['.$num.'].model');
$vid = exec('uci get dongles.@dongle['.$num.'].vid');
$pid = exec('uci get dongles.@dongle['.$num.'].pid');
$data = exec('uci get dongles.@dongle['.$num.'].data');
$status = exec('uci get dongles.@dongle['.$num.'].status');

exec('uci set dongle.current.brand=\''.$brand.'\'');
exec('uci set dongle.current.model=\''.$model.'\'');
exec('uci set dongle.current.vid=\''.$vid.'\'');
exec('uci set dongle.current.pid=\''.$pid.'\'');
exec('uci set dongle.current.data=\''.$data.'\'');
exec('uci set dongle.current.status=\''.$status.'\'');

//echo $data.'<br>';
//echo $status.'<br>';


if ($connectiontype == "dhcp") {
	exec('uci set conntype.dhcp=1');
	exec('uci set conntype.3g=0');
	exec('uci set conntype.pppoe=0');
	exec('uci set conntype.static=0');
	exec('uci delete network.wan.apn');
	exec('uci delete network.wan.auto');
	exec('uci delete network.wan.service');
	exec('uci delete network.wan.pincode');	
	exec('uci delete network.wan.username');
	exec('uci delete network.wan.password');
	exec('uci delete network.wan.keepalive');
	exec('uci delete network.wan.ipaddr');
	exec('uci delete network.wan.netmask');
	exec('uci delete network.wan.gateway');
	exec('uci delete network.wan.dns');
	exec('uci delete network.wan.device');
	exec('uci set network.wan.ifname=eth1');
	exec('uci set network.wan.proto=\''.$connectiontype.'\'');
} elseif ($connectiontype == "pppoe") {
	exec('uci set conntype.dhcp=0');
	exec('uci set conntype.3g=0');
	exec('uci set conntype.pppoe=1');
	exec('uci set conntype.static=0');
	exec('uci delete network.wan.apn');
	exec('uci delete network.wan.auto');
	exec('uci delete network.wan.service');
	exec('uci delete network.wan.pincode');	
	exec('uci delete network.wan.username');
	exec('uci delete network.wan.password');
	exec('uci delete network.wan.keepalive');
	exec('uci delete network.wan.ipaddr');
	exec('uci delete network.wan.netmask');
	exec('uci delete network.wan.gateway');
	exec('uci delete network.wan.dns');
	exec('uci delete network.wan.device');
	exec('uci set network.wan.ifname=eth1');
	exec('uci set network.wan.proto=\''.$connectiontype.'\'');
	exec('uci set network.wan.username=\''.$username.'\'');
	exec('uci set network.wan.password=\''.$password.'\'');
	exec('uci set network.wan.keepalive=3');
	exec('uci set conntype.pppoe.user=\''.$username.'\'');
	exec('uci set conntype.pppoe.pass=\''.$password.'\'');
} elseif ($connectiontype == "static") {
	exec('uci set conntype.dhcp=0');
	exec('uci set conntype.3g=0');
	exec('uci set conntype.pppoe=0');
	exec('uci set conntype.static=1');
	exec('uci delete network.wan.apn');
	exec('uci delete network.wan.auto');
	exec('uci delete network.wan.service');
	exec('uci delete network.wan.pincode');	
	exec('uci delete network.wan.username');
	exec('uci delete network.wan.password');
	exec('uci delete network.wan.keepalive');
	exec('uci delete network.wan.device');
	exec('uci set network.wan.ifname=eth1');
	exec('uci set network.wan.proto=\''.$connectiontype.'\'');
	exec('uci set network.wan.ipaddr=\''.$ipaddr.'\'');
	exec('uci set network.wan.netmask=\''.$netmask.'\'');
	exec('uci set network.wan.gateway=\''.$gateway.'\'');
	exec('uci set network.wan.dns='.$dns);
	exec('uci set conntype.static.ipaddr=\''.$ipaddr.'\'');
	exec('uci set conntype.static.netmask=\''.$netmask.'\'');
	exec('uci set conntype.static.gateway=\''.$gateway.'\'');
	exec('uci set conntype.static.dns='.$dns);
} elseif ($connectiontype == "3g") {
	exec('uci set conntype.dhcp=0');
	exec('uci set conntype.3g=1');
	exec('uci set conntype.pppoe=0');
	exec('uci set conntype.static=0');
	exec('uci delete network.wan.ipaddr');
	exec('uci delete network.wan.netmask');
	exec('uci delete network.wan.gateway');
	exec('uci delete network.wan.dns');	
	exec('uci set network.wan.apn=\''.$apn3g.'\'');
	exec('uci set network.wan.proto=\''.$connectiontype.'\'');
	exec('uci set network.wan.username=\''.$username3g.'\'');
	exec('uci set network.wan.password=\''.$password3g.'\'');
	exec('uci set network.wan.pincode=\''.$pin3g.'\'');
 	exec('uci set network.wan.device=\'/dev/'.$data.'\''); 
	exec('uci set network.wan.keepalive=\'1\'');
	exec('uci set network.wan.auto=\'1\'');
	exec('uci set network.wan.ifname=\'ppp0\'');
	exec('uci set network.wan.service=\'umts\'');
	exec('sed -i \'2d\' /etc/minirc.dfl');
	exec('sed -i \'2i pu port             /dev/'.$status.'\' /etc/minirc.dfl');
	exec('uci set conntype.3g.apn=\''.$apn3g.'\'');
	exec('uci set conntype.3g.user=\''.$username3g.'\'');
	exec('uci set conntype.3g.pass=\''.$password3g.'\'');
	exec('uci set conntype.3g.pincode=\''.$pin3g.'\'');
}

exec('uci commit');
//exec('/etc/init.d/network restart');
exec('(sleep 5 && reboot)&');
#sleep(2);
?>

