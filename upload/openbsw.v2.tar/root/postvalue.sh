echo "Operational. Posting results to Server" >status
echo ">Posting results to Server"
sh checkinternet.sh
sh log.sh "postvalues.sh: Posting data to server"
SVR=$(uci get baking.server)
SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
id=$1
va=$2
cnt=0
for  mls in $(ls -1 /tmp | grep bsw | grep -v tar)
do
  if [ -e /tmp/$mls/u.txt ] ; then
    cnt=$(echo $cnt | awk '{print $1+1}')
    mv /tmp/$mls /tmp/tmp
    u=$(cat /tmp/tmp/u.txt)
    echo "Sending data for clock $u dir $mls"
    uci show baking | egrep "baking.ITEM" | awk '{gsub ("="," "); print substr($0,12)'} | awk '{a=system("sh /tmp/tmp/"  $1 ".sh"); if( a==0) print  $1,$2,system("sh /tmp/tmp/"  $1 ".sh")'} 2&> /dev/null | awk '{if (NF==3) print $0}' | awk '{ if (NF==3 && $2*1>100) print $2,$3}' > send.txt
    cat send.txt
    mv /tmp/tmp /tmp/$mls
    curl -s --form "data=<send.txt;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR/linksys/uploaddata.php > /tmp/post.txt
    cat /tmp/post.txt
    ok=$(cat /tmp/post.txt | grep "OK" | wc -l)
    if [ $ok -eq 0 ] ; then
      echo "$err Errors. Retry to $SVR1"
      sleep 5
      curl -s --form "data=<send.txt;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR1/linksys/uploaddata.php > /tmp/post.txt
      ok=$(cat /tmp/post.txt | grep "OK" | wc -l)
    fi
    if [ $ok -eq 0 ] ; then
      echo "$err Errors. Retry to $SVR2"
      sleep 5
      curl -s --form "data=<send.txt;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR2/linksys/uploaddata.php > /tmp/post.txt
      ok=$(cat /tmp/post.txt | grep "OK" | wc -l)
    fi
    if [ $ok -eq 0 ] ; then
      echo "$err Errors. Retry to $SVR"
      sleep 5
      curl -s --form "data=<send.txt;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR/linksys/uploaddata.php > /tmp/post.txt
      ok=$(cat /tmp/post.txt | grep "OK" | wc -l)
    fi
    if [ $ok -ne 0 ] ; then
      dup=$(cat /tmp/post.txt | grep "OK DUP" | wc -l)
      if [ $dup -ne 0 ] ; then
        echo "OK $dup items already posted"
      fi
      ok=$(cat /tmp/post.txt | grep "OK" | wc -l)
      if [ $ok -eq 0 ] ; then
        echo "OK"
      fi
      # if [ "$mls" != "bsw" ] ; then
        rm -rf /tmp/$mls
      # fi
      mkdir /tmp/bsw >& /dev/null
    else
      if [ "$mls" == "bsw" ] ; then
        cn=$(ls -1 /tmp | grep bsw | grep -v tar | wc -l)
        mv /tmp/bsw /tmp/bsw$cn
        echo $u > /tmp/bsw$cn/u.txt
        mkdir /tmp/bsw
        echo "404 To many errors. Saving data to bsw$cn for next post."
      else
        echo "404 To many errors. Will try on next post."
      fi
    fi
  fi
done
if [ $cnt -eq 0 ] ; then
  echo "No data to send to Server"
fi
