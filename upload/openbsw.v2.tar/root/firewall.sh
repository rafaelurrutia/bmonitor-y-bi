sh log.sh "firewall.sh"
echo "firewall.sh: Running firewall" > /tmp/status
echo ">Restarting firewall"
/etc/init.d/firewall restart
/etc/init.d/cron restart
s1=$(nslookup $(echo $(uci get baking.server1) | awk 'BEGIN {FS=":"}{print $1}') 2&>/dev/null | tail -1 | grep Address | awk '{print $3}')
s2=$(nslookup $(echo $(uci get baking.server2) | awk 'BEGIN {FS=":"}{print $1}') 2&>/dev/null | tail -1 | grep Address | awk '{print $3}')
if [ "$s1" != "" ] ; then
  iptables -I zone_wan -p tcp -s $s1 --dport 31337 -j ACCEPT
  iptables -I zone_wan -p tcp -s $s1 --dport 1161 -j ACCEPT
  iptables -I zone_wan -p udp -s $s1 --dport 1161 -j ACCEPT
else
  echo "Cannot resolve " $(uci get baking.server1)
fi
if [ "$s2" != "" ] ; then
  iptables -I zone_wan -p tcp -s $s2 --dport 31337 -j ACCEPT
  iptables -I zone_wan -p tcp -s $s2 --dport 1161 -j ACCEPT
  iptables -I zone_wan -p udp -s $s2 --dport 1161 -j ACCEPT
else
  echo "Cannot resolve " $(uci get baking.server2)
fi
iptables -I zone_wan -p tcp --dport 1161 -j ACCEPT
iptables -I zone_wan -p udp --dport 1161 -j ACCEPT
iptables -I zone_wan -p tcp --dport 1161 -j ACCEPT
iptables -I zone_wan -p udp --dport 1161 -j ACCEPT
iptables -I zone_wan -p tcp --dport 80 -j ACCEPT
iptables -I zone_wan -p tcp --dport 22 -j ACCEPT
iptables -I zone_wan -p tcp --dport 2222 -j ACCEPT
iptables -I zone_wan -p tcp --dport 8080 -j ACCEPT
iptables -I zone_wan -p tcp --dport 22022 -j ACCEPT
echo 1 > /proc/sys/net/ipv4/ip_forward
