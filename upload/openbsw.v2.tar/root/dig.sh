cd /root
x=0
tm=0
echo -n $(date +"%s")>/tmp/dig.lease
while [ $x -eq 0 ] ; do
  x=$(dig +nocmd google.com any +noall +answer | wc -l)
  let tm=$tm+1
  if [ $tm -eq 700 ] ; then
    x=-1
  fi
done   
echo -n " ">>/tmp/dig.lease
echo -n $(date +"%s")>>/tmp/dig.lease
ttime=$(cat /tmp/dig.lease  | awk '{print "echo ",($2 - $1)}')
dt=$(date)
echo $dt > /tmp/dig.txt
cat /tmp/dig.lease  | awk '{print "Dig:",($2 - $1)}' >> /tmp/dig.txt
cat /tmp/dig.txt
echo $ttime >/tmp/bsw/IPloginRENEW.sh
echo "echo " $x > /tmp/bsw/IPloginRENEW_status.sh
if [ $x -eq -1 ] ; then
  echo "echo 0" > /tmp/bsw/IPloginRENEW_status.sh
  echo "echo 0" > /tmp/bsw/IPloginOK.sh
else
  echo "echo 1 " > /tmp/bsw/IPloginRENEW_status.sh
  val=$(sh /tmp/bsw/IPloginRENEW.sh)
  min=$(uci get baking.renew)
  if [ $val -le $min ] ; then
    echo "echo 1">/tmp/bsw/IPloginOK.sh
  else
    echo "echo 0">/tmp/bsw/IPloginOK.sh
  fi
fi
d=$(cat dodig)
if [ $d -eq 1 ] ; then
  cp /tmp/bsw/ip* /root/bsw
fi
echo 0 > dodig
