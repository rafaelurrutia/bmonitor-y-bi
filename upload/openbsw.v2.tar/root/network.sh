
if [ -s iflock ] ; then
  echo "Exit"
  exit
fi

mkdir /tmp/ifdata 2&> /dev/null

u=$(date +"%s")
ifin=$(snmpget -v2c -cpublic localhost:1161 iso.3.6.1.2.1.2.2.1.10.3 2&> /dev/null | awk '{ print $4}')
ifout=$(snmpget -v2c -cpublic localhost:1161 iso.3.6.1.2.1.2.2.1.16.3 2&> /dev/null | awk '{ print $4}')
d=$(date +"%M")

inold=0
outold=0
if [ -s ifin ] ; then
  inold=$(cat ifin)
fi
if [ -s ifout ] ; then
  outold=$(cat ifout)
fi

echo $ifin > ifin
echo $ifout > ifout

if [ $inold -ne 0 ] ; then
  let difin=$ifin-$inold
  if [ $difin -lt 0 ] ; then
    difin=$ifin
  fi
  let difout=$ifout-$outold
  if [ $difout -lt 0 ] ; then
    difout=$ifout
  fi
fi

if [ -s /tmp/ifdata/$d.in ] ; then
  n=$(date +"%s")
  d=$d.$n
fi
echo $difin > /tmp/ifdata/$d.in
echo $difout > /tmp/ifdata/$d.out

echo $difin $difout - $ifin $ifout
