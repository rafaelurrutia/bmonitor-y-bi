rm /root/bsw/* >& /dev/null
cp /tmp/bsw/* /root/bsw >& /dev/null
reboot
