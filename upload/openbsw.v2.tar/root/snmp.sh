
mkdir /tmp/ifdata 2&> /dev/null
sleep 5
echo 1 > iflock
u=$(date +"%s")
#ifin=$(snmpget -v2c -cpublic localhost:1161 iso.3.6.1.2.1.2.2.1.10.3 2&> /dev/null | awk '{ print $4}')
#ifout=$(snmpget -v2c -cpublic localhost:1161 iso.3.6.1.2.1.2.2.1.16.3 2&> /dev/null | awk '{ print $4}')

difin=$(cat /tmp/ifdata/*.in 2&>/dev/null | awk 'BEGIN {a=0}{a=a+$0}END{print a}')
difout=$(cat /tmp/ifdata/*.out 2&>/dev/null | awk 'BEGIN {a=0}{a=a+$0}END{print a}')
rm /tmp/ifdata/*.in /tmp/ifdata/*.out 2&>/dev/null

echo $u > /tmp/ifdata/ifdata
echo "echo $difin" > /tmp/ifdata/LOCbandwidthbytedown.sh
echo "echo $difout" > /tmp/ifdata/LOCbandwidthbyteup.sh

echo "in:$difin out:$difout"

u=$(cat /tmp/ifdata/ifdata)                                                                                                                                                                                                                                                                                                       
uci show baking | egrep "baking.ITEM" | awk '{gsub ("="," "); print substr($0,12)'} | awk '{a=system("sh /tmp/ifdata/"  $1 ".sh"); if( a==0) print  $1,$2,system("sh /tmp/ifdata/"  $1 ".sh")'} 2&> /dev/null | awk '{if (NF==3) print $0}' | awk '{ if (NF==3 && $2*1>100) print $2,$3}' > ifsend.txt 
mv ifsend.txt /tmp/ifdata/$u.dat

sh postif.sh 

#echo $ifin > ifin
#echo $ifout > ifout

rm iflock
