echo "Operational. Posting if results to Server" >status
echo ">Posting results to Server"
SVR=$(uci get baking.server)
SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
for  mls in $(ls -1 /tmp/ifdata/*.dat)
do
    u=$(echo $mls |  awk 'BEGIN {FS="."}{print substr($1,13)}')
    echo "Sending ifdata for clock $u"
    curl -s --form "data=<$mls;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR/linksys/uploaddata.php > /tmp/ifpost.txt
    cat /tmp/ifpost.txt
    ok=$(cat /tmp/ifpost.txt | grep "OK" | wc -l)
    if [ $ok -eq 0 ] ; then
      echo "$err Errors. Retry to $SVR1"
      sleep 5
      curl -s --form "data=<$mls;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR1/linksys/uploaddata.php > /tmp/ifpost.txt
      ok=$(cat /tmp/ifpost.txt | grep "OK" | wc -l)
    fi
    if [ $ok -eq 0 ] ; then
      echo "$err Errors. Retry to $SVR2"
      sleep 5
      curl -s --form "data=<$mls;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR2/linksys/uploaddata.php > /tmp/ifpost.txt
      ok=$(cat /tmp/ifpost.txt | grep "OK" | wc -l)
    fi
    if [ $ok -eq 0 ] ; then
      echo "$err Errors. Retry to $SVR"
      sleep 5
      curl -s --form "data=<$mls;type=text/text" --form u=$u --form mac=$(sh getmac.sh)  http://$SVR/linksys/uploaddata.php > /tmp/postif.txt
      ok=$(cat /tmp/ifpost.txt | grep "OK" | wc -l)
    fi
    if [ $ok -ne 0 ] ; then
      dup=$(cat /tmp/ifpost.txt | grep "OK DUP" | wc -l)
      if [ $dup -ne 0 ] ; then
        echo "OK $dup items already posted"
        rm $mls
      fi
      ok=$(cat /tmp/ifpost.txt | grep "OK" | wc -l)
      if [ $ok -ne 0 ] ; then
        echo "Sent OK"
        #rm /tmp/ifdata/*.sh
        rm $mls
      fi
      else
        echo "Error"
    fi
done
