com=$(cat /proc/cpuinfo | grep "cpu model\|model name" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
rou=$(cat /proc/cpuinfo | grep "machine" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
boa=$(cat /proc/cpuinfo | grep "system type" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
if [ "$boa" == "" ] ; then
  boa=$(uname -m)
fi
w=$(cat /tmp/nextrun.txt | grep Working | wc -l)
ss=$(ps | grep snmpd | grep -v grep | wc -l)
if [ $ss -eq 0 ] ; then
  /etc/init.d/snmpd start
fi
rm -rf x.test
> x.test
if [ $? -eq 1 ] ; then
  sleep 60
  reboot
fi
SVR1=$(uci get baking.server1)
if [ $? -eq 1 ] ; then
  cp /etc/config/bakingbak  /etc/config/baking
  sh /tmp/config.sh >& /dev/null
  SVR1=$(uci get baking.server1)
fi
SVR2=$(uci get baking.server2)
SVR=$(uci get baking.server)

if [ $w -eq 0 ] ; then # si el router está idle, entonces comenzar.
  > full
  if [ $? -eq 1 ] ; then
    sleep 60
    reboot
  fi
  rm -f full
  w=$(uci get system.bswkeepalive)
  if [ $w -eq 0 ] ; then # si no se está ejecutando keepalive, entoces ejecutar.
    sh log.sh "keepalive.sh"
    sh checkinternet.sh
    uci set system.bswkeepalive=1
    uci commit system
    rm -f /tmp/wg.run >& /dev/null
    rm -f /tmp/wg.run1 >& /dev/null
    rm -f /tmp/wg.run2 >& /dev/null
    mac=$(sh getmac.sh)
    hos=$(uci get system.@system[0].hostname | awk '{gsub(" ","_"); print $1}')
    ip=$(sh getip.sh)
    ver1=$(uci get system.version)
    wget -T 2 -O /tmp/wg.run1 "http://$SVR/linksys/keepalive.php?ips=$ip&ver=$ver1&mac=$mac&boa=$boa&rou=$rou&hos=$hos&fll=0" >& /dev/null
    g=$(cat /tmp/wg.run1 | grep END | wc -l)
    if [ $g -eq 0 ] ; then        
      SVR=$SVR1
      rm /tmp/wg.run1 >& /dev/null
      wget -T 2 -O /tmp/wg.run1 "http://$SVR1/linksys/keepalive.php?ips=$ip&ver=$ver1&mac=$mac&boa=$boa&rou=$rou&hos=$hos&fll=0" >& /dev/null
    fi
    g=$(cat /tmp/wg.run1 | grep END | wc -l)
    if [ $g -eq 0 ] ; then
      rm /tmp/wg.run1 >& /dev/null
    fi
    if [ -s /tmp/wg.run1 ] ; then
      uci set baking.server=$SVR
      uci commit
      sh /tmp/wg.run1 >& /dev/null
      echo "Server $SVR respond" > /tmp/keepalive.txt
      v=$(cat /tmp/wg.run1 | grep $ver1 | wc -l)
    else
      SVR=$SVR2
      wget -T 2 -O /tmp/wg.run2 "http://$SVR2/linksys/keepalive.php?ips=$ip&ver=$ver&mac=$mac&boa=$boa&rou=$rou&hos=$hos&fll=0" >& /dev/null
      g=$(cat /tmp/wg.run2 | grep END | wc -l)
      if [ $g -eq 0 ] ; then
        rm /tmp/wg.run2 >& /dev/null
      fi
      if [ -s /tmp/wg.run2 ] ; then
        uci set baking.server=$SVR
        uci commit
        sh /tmp/wg.run2 >& /dev/null
        echo "Server $SVR respond" > /tmp/keepalive.txt
      else
        echo "Servers did not respond" > /tmp/keepalive.txt
      fi
    fi
    par1=$(uci get baking.pcontrol)
    if [ ! -e /tmp/config.sh ] ; then
      sh log.sh "keepalive.sh: Download config"
      wget -T 2 -O /tmp/config.sh  "http://$SVR/linksys/config2.php?mac=$mac" >& /dev/null
      cat /tmp/config.sh | awk '{gsub("\r",""); print $0;}' > /tmp/config.bak
      mv /tmp/config.bak /tmp/config.sh
       
      sh /tmp/config.sh >& /dev/null
      sh httppage.sh
      r=$(cat /tmp/config.sh | grep ITEM | wc -l)
      if [ $r -eq 1 ] ; then
        rm /tmp/config.sh >& /dev/null
      fi
      if [ $r -eq 0 ] ; then
        rm /tmp/config.sh >& /dev/null
      fi
      if [ -e /tmp/config.sh ] ; then
        echo $(date) > lastconfig
      fi
      par2=$(uci get baking.pcontrol)
      if [ "$par1" != "$par2" ] ; then
        sh firewall.sh
        if [ "$par2" == "1" ] ; then
          sh pcontrol.sh
        fi
      fi
      par1=$par2
      echo "Posting Data after reboot" > status
      sh httppage.sh
      sh trap.sh
      sh postvalue.sh
      sleep 5
    fi
    ver2=$(uci get system.version) 
    cp=$(iptables -t nat -L | grep ":53" | wc -l)
    if [ $cp -eq 0 ] && [ $par1 -eq 1 ] ; then
      sh pcontrol.sh
    fi
    if [ "$ver1" != "$ver2" ] ; then
      echo "PERFORMING UPGRADE FROM $ver1 TO $ver2"
      sh restore.sh
    fi
    uci set system.bswkeepalive=0
    uci commit system
    echo "echo $ver2" > /tmp/bsw/version.sh
  fi
fi
                                                    
