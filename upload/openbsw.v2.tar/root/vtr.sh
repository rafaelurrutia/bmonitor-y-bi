exit 
if3g=$(ifconfig -a | grep 3g-wan | wc -l)
if [ $if3g -eq 0  ] ; then
  exit
fi
echo "Checking for VTR IP"
export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin
vid=$(uci get dongle.current.vid)
pid=$(uci get dongle.current.pid)
usb_modeswitch -I -W -R -v $vid -p $pid -c /etc/usb_modeswitch.d/$vid\:$pid
echo "$(uci -q get dongle.current.vid) $(uci -q get dongle.current.modempid)" > /sys/bus/usb-serial/drivers/option1/new_id
                   
OK=$(ifconfig | grep P-t-P | egrep "addr:190.|addr:200." | wc -l)
echo "IP:$OK"
while [ $OK -eq 0 ] ; do
  echo "Find VTR IP" > status
  cpu=$(cat /proc/cpuinfo | grep "cpu model" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
  eth=$(netstat -nr | grep "^0.0.0.0" | awk '{print $8}')
  if3g=$(ifconfig -a | grep 3g-wan | wc -l)
  if [ $if3g -eq 1 ] ; then
    gcom -s /etc/gcom/GPRSdown.gcom >& /dev/null
  else
    ifconfig $eth down  >& /dev/null
    ifconfig $eth 1.1.1.1 up  >& /dev/null
  fi
    
  x=0
  tm=0
  if [ "$cpu" == "MIPS 24Kc V7.4" ] ; then
    if [ $if3g -eq 0 ] ; then
      /etc/init.d/network stop >& /dev/null
    fi
    /etc/init.d/network start &
  else
    udhcpc -q -i $eth -T9 -n>leaset.txt &
  fi
  while [ $x -eq 0 ] ; do
    x=$(dig +nocmd google.com any +noall +answer | wc -l)
    let tm=$tm+1
    if [ $tm -eq 700 ] ; then
      x=-1
    fi
  done
  OK=$(ifconfig | grep P-t-P | egrep "addr:190.|addr:200." | wc -l)
  echo "IP:$OK"
  if [ $OK -eq 1 ] ; then
    par=$(uci get baking.pcontrol)
    sh firewall.sh
    if [ $par -eq 1 ] ; then
      sh pcontrol.sh
    fi
  else
    vid=$(uci get dongle.current.vid)
    pid=$(uci get dongle.current.pid)
    usb_modeswitch -I -W -R -v $vid -p $pid -c /etc/usb_modeswitch.d/$vid\:$pid
    echo "$(uci -q get dongle.current.vid) $(uci -q get dongle.current.modempid)" > /sys/bus/usb-serial/drivers/option1/new_id
  fi
done     
