tt=$1
res="NO"
if [ "$tt" == "" ] ; then
  res="OK"
fi
if [ "$tt" == "7x24" ] ; then
  res="OK"
fi
if [ "$tt" == "7x24x365" ] ; then
  res="OK"
fi
while [ "$tt" != "" ] ; do
  if [ "$res" == "NO" ] ; then
    r1=$(echo $tt | awk 'BEGIN {FS=";"}{print $1}')
    d=$(echo $r1 | awk 'BEGIN {FS=","}{print $1}')
    h=$(echo $r1 | awk 'BEGIN {FS=","}{print $2}')
              
    hasdash=$(echo $d | awk 'BEGIN{FS="-"}{if (NF==1) print 1; else print 0}')
    if [ $hasdash -eq 0 ] ; then
      d0=$(echo $d | awk 'BEGIN {FS="-"}{print $1}')
      d1=$(echo $d | awk 'BEGIN {FS="-"}{print $2}')
    else
      d0=$d
      d1=$d
    fi
                                      
    dayofweek=$(date +"%u")
    today=0
                                                              
    for i in $(seq $d0 $d1) ; do
       if [ $i -eq $dayofweek ] ; then
         today=1
       fi
    done
    if [ $today -eq 1 ] ; then
      haspoints=$(echo $h | awk 'BEGIN{FS="-"}{if (NF==1) print 1; else print 0}')
      if [ $haspoints -eq 0 ] ; then
        h1=$(echo $h | awk 'BEGIN {FS="-"}{print $1}')
        h2=$(echo $h | awk 'BEGIN {FS="-"}{print $2}')
      else
        h1=$h
        h2="24:00"
      fi
      if [ "$2" ==  "" ] ; then
        mh=$(date +"%H")
        mm=$(date +"%M")         
      else
        mh=$(awk -vd=$2 'BEGIN{print strftime("%H",systime()+d*60*60)}')
        mm=$(awk -vd=$2 'BEGIN{print strftime("%M",systime()+d*60*60)}')
      fi      
      x1h=$(echo $h1 | awk 'BEGIN {FS=":"}{print $1}')
      x1m=$(echo $h1 | awk 'BEGIN {FS=":"}{if (NF==1) print 0; else print $2}')
      x2h=$(echo $h2 | awk 'BEGIN {FS=":"}{print $1}')
      x2m=$(echo $h2 | awk 'BEGIN {FS=":"}{if (NF==1) print 0; else print $2}')
                                                                                    
      res=$(echo $mh $mm $x1h $x1m $x2h $x2m | awk '{h=$1*60+$2;h1=$3*60+$4;h2=$5*60+$6}END{if (h >= h1 && h <= h2) print "OK"; else print "NO"}')
    else
      res="NO"
    fi
  fi
  a=$(echo $tt | awk 'BEGIN {FS=";"}{for (i=2;i<=NF;i++) print $(i) ";";}' | awk '{ print substr($0,1,length($0)-1)}')
  tt=$a
done
if [ "$res" == "" ] ; then
  res="NO"
fi
echo $res

