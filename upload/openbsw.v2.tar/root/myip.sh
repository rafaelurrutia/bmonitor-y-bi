if [ -s /var/state/network ] ; then
  et=$(cat /var/state/network | grep wan.device | awk 'BEGIN {FS="="}{print $2}')
  n=$(ifconfig | grep $et | wc -l)
  if [ $n -eq 1 ] ; then
    ip=$(ifconfig $et | grep inet | awk '{print substr($2,6)}')
  fi
  if [ "$ip" == "" ] ; then
    et=$(cat /var/state/network | grep wan.ifname | awk 'BEGIN {FS="="}{print $2}')
    ip=$(ifconfig $et | grep inet | awk '{print substr($2,6)}')
  fi
else
  ip=$(uci -P /var/state get network.wan.ipaddr)
fi
if [ "$ip" == "" ] ; then
  ip=$(uci get network.wan.ipaddr 2> /dev/null)
fi
echo $ip                                                                                        
