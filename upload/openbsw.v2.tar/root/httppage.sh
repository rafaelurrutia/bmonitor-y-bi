cd /root
quote=""

SVR1=$(uci get baking.server1)
SVR2=$(uci get baking.server2)
SVR=$(uci get baking.server)
com=$(cat /proc/cpuinfo | grep "cpu model\|model name" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
rou=$(cat /proc/cpuinfo | grep "machine" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
if [ "$rou" == "" ] ; then 
  v=$(dmesg | grep "VBOX HARDDISK" | grep ata | wc -l)
  if [ $v -eq 1 ] ; then
    rou="Virtual Box"
  fi
fi
boa=$(cat /proc/cpuinfo | grep "system type" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
if [ "$boa" == "" ] ; then                                                                                                                                                                                                                                                                                       
  boa=$(uname -m)                                                                                                                                                                                                                                                                                                
fi    
[ -s /etc/config/dongle ] && {
        statusport=$(uci get dongle.current.status)
        sstrength=$(gcom -d /dev/$statusport sig | cut -f3 -d' ' | cut -f1 -d',')
        if [ "$sstrength" == "device" ]; then
                sstrength="N/A"
        fi
} || {
        sstrength="N/A"
}
nextrun=""
ttime=""
if [ -f /tmp/nextrun.txt ] ; then
  nextrun=$(cat /tmp/nextrun.txt)
fi
if [ -s testduration ] ; then
  ttime=$(cat testduration)
  if [ -s /tmp/bsw/u.txt ] ; then
    tdate=$(cat /tmp/bsw/u.txt | awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')
    ttime="$ttime @ $tdate" 
  fi
else
  ttime=""
fi
st=$(cat status)
mac=$(sh getmac.sh)
par=$(uci get baking.pcontrol 2&> /dev/null)
hos=$(uci get system.@system[0].hostname 2&> /dev/null) 
ip=$(sh getip.sh)
lio=$(uci -P /var/state get network.lan.ipaddr 2&> /dev/null)
if [ "$par" == "1" ] ; then
  par="Enabled"
else
  par="Disabled"
fi

ver=$(uci get system.version)
lastboot=$(cat lastboot| awk '{ print strftime("%d/%m/%Y %H:%M:%S",$1)}')

w=/www/index.html
rm /www/index.php &> /dev/null
d=$(date)
utime=$(uptime)
uname=$(uname -a)
vacation=""
vac1=$(uci get baking.ndw1 2&> /dev/null)
vac2=$(uci get baking.ndw2 2&> /dev/null)
if [ "$vac1" != "" ] ; then
  ddt=$(date +"%s")
  if [ $vac2 -gt $ddt ] ; then
    v1=$(echo $vac1 | awk '{ print strftime("%d/%m/%Y",$1+3600*3)}')
    v2=$(echo $vac2 | awk '{ print strftime("%d/%m/%Y",$1-3600*3)}')
    vacation="$v1 - $v2"
  fi
fi
working=$(uci get baking.horario 2&> /dev/null)
plan=$(uci get baking.plan 2&> /dev/null)
delay=$(uci get baking.delay 2&> /dev/null)
wf=$(uci get wireless.radio0.disabled 2&> /dev/null)
nwd=$(uci get baking.feriados 2&> /dev/nyll)
if [ "$wf" == "" ] ; then                          
  wf="N/A"                                                                       
else                                         
  if [ $wf -eq 1 ] ; then      
    wf="Disabled"              
  else                         
    wf="Enabled"               
  fi                           
fi   
                
if [ -e /tmp/config.sh ] ; then
  dt=$(cat lastconfig)
  conf="Yes [$dt]"
else
  conf="No"
  plan=""
  delay=""
  working=""
  state="Idle"
fi

x=$(uci show system | grep status | wc -l)     
if [ $x -eq 1 ] ; then                         
  xst=$(uci get system.status)                  
  if [ $xst -eq 1 ] ; then                      
    st="Router disabled on server"
    ttime="00:00:00"
  fi                                                             
fi        

statusport=$(uci get dongles.current.status);
sstrength=$(gcom -d /dev/$statusport sig | cut -f3 -d' ' | cut -f1 -d',');
if [ "$sstrength" == 'device' ] ; then 
	sstrength='N/A';
fi
	
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">                                                                            
<html xmlns="http://www.w3.org/1999/xhtml">                                                                                                                                              
<head>                                                                                                                                                                                   
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />                                                                                                               
<meta http-equiv="refresh" content="10" />                                                                                                                         
<meta http-equiv="PRAGMA" content="NO-CACHE" />                                                                                                                                          
<meta http-equiv="EXPIRES" content="-1" />                                                                                                                                               
<title>::Baking Sofware - bFirmware - 2012</title>                                                                                                                                       
<link rel="stylesheet" type="text/css" href="index.css" />                                                                                                                               
</head>                                                                                                                                                                                  
<body>' > $w
	
echo '<table><div class="logo"><a href="http://www.bsw.cl"><img src="logo.png" width="300" height="71" alt="BakingSoftware" /></a></div>' >> $w;
echo "<thead><tr><th colspan="2" scope="row" class="column1"> Hora del Router: $DATE </th></tr>" >> $w;
echo '<tr class="odd"><td class="column1"></td><th scope="col" abbr="Home">Valores</th></tr></thead>' >> $w;
echo '<tbody>' >> $w;
echo "<tr><th scope="row" class="column1">Router</th><td>$hos</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Mac</th><td>$mac</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Plan</th><td>$plan</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Public IP</th><td>$ip</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Local IP</th><td>$lio</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Version</th><td>$ver</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Board</th><td>$boa</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Machine</th><td>$rou</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Model</th><td>$com</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">WiFi</th><td>$wf</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Parental Control</th><td>$par</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Config File</th><td>$conf</td><tr>" >> $w
echo "<tr><th scope="row" class="column1">Active Server</th><td>$SVR</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Server 1</th><td>$SVR1</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Server 2</th><td>$SVR2</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Status</th><td>$st</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Next run</th><td>$nextrun</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Run every</th><td>$delay seconds</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Working hours</th><td>$working</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Hollidays</th><td>$nwd</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Last update</th><td>$d</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Test duration</th><td>$ttime</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">System </th><td>$uname</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Uptime </th><td>$utime</td></tr>" >> $w
echo "<tr><th scope="row" class="column1">Last Boot </th><td>$lastboot</td></tr>" >> $w
echo "<tr class="odd"><th scope="row" class="column1">Signal Strength</th><td>$sstrength</td></tr>" >> $w;
echo '</tbody></table></body></html>' >> $w;
	
#q=$(cat quote.txt)
#echo "<br><br><center><big><italic>$q</italic></big></center>" >> $w
dd=$(date +"%s")
echo $dd > lastalive
