export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin
sh log.sh "runnenew.sh"
echo "Operational. Performing Test Renew" > status
cpu=$(cat /proc/cpuinfo | grep "cpu model" | awk 'BEGIN { FS=":"} { print substr($2,2) }')
eth=$(netstat -nr | grep "^0.0.0.0" | awk '{print $8}')
if3g=$(ifconfig -a | grep 3g-wan | wc -l)
if [ $if3g -eq 1 ] ; then
  gcom -s /etc/gcom/GPRSdown.gcom  
  /etc/init.d/network stop >& /dev/null
else
  ifconfig $eth down
  ifconfig $eth 1.1.1.1 up
fi
    
#x=0
#tm=0
if [ "$cpu" == "MIPS 24Kc V7.4" ] ; then
  echo "Runnng Stop/Start"
  if [ $if3g -eq 0 ] ; then
    /etc/init.d/network stop >& /dev/null
  fi
  /etc/init.d/network start &
else
  echo "Running udhcpc"
  udhcpc -q -i $eth -T9 -n>leaset.txt &
fi
#echo -n $(date +"%s")>/tmp/leasetime.txt
#while [ $x -eq 0 ] ; do
#  x=$(dig +nocmd google.com any +noall +answer | wc -l)
#  let tm=$tm+1
#  if [ $tm -eq 700 ] ; then
#    x=-1
#  fi
#done     
#sh log.sh "runrenew.sh: Done in $tm cycles"
#echo " " $(date +"%s") >>/tmp/leasetime.txt
#cat /tmp/leasetime.txt  | awk '{print "echo ",$2 - $1}'>/tmp/bsw/IPloginRENEW.sh
#echo "echo " $x > /tmp/bsw/IPloginRENEW_status.sh
#if [ $x -eq -1 ] ; then
#  echo "echo 0" > /tmp/bsw/IPloginRENEW_status.sh  
#  echo "echo 0" > /tmp/bsw/IPloginOK.sh
#  sh log.sh "Renew.sh: Timeout. Network Restart [$tm]"
#else
#  echo "echo 1 " > /tmp/bsw/IPloginRENEW_status.sh  
#  val=$(sh /tmp/bsw/IPloginRENEW.sh)
#  min=$(uci get baking.renew)                                                                 
#  if [ $val -le $min ] ; then
#    echo "echo 1">/tmp/bsw/IPloginOK.sh
#  else
#    cat /tmp/leasetime.txt  | awk '{print "echo ",-($2 - $1)}'>/tmp/bsw/IPloginRENEW.sh
#    echo "echo 0">/tmp/bsw/IPloginOK.sh
#  fi
#fi
sh dig.sh &
dg=1
while [ $dg -ge 1 ] ; do
  sleep 5
  dg=$(ps | grep dig.sh | grep -v grep | wc -l)
done
if [ $if3g -eq 1 ] ; then
  isok=$(sh /tmp/bsw/IPloginOK.sh)
  if [ $isok -eq 0 ] ; then
    echo 1 > dodig
    > fastboot
    sh reboot.sh
  fi
fi
echo "Done renew process"
sleep 5
par=$(uci get baking.pcontrol)
sh firewall.sh
if [ $par -eq 1 ] ; then
  sh pcontrol.sh
fi
sh vtr.sh
