
. /lib/functions/network.sh;
network_get_ipaddr ip wan;
echo $ip;
