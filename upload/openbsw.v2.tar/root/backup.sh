rm /tmp/*.tar
rm /root/bsw/*
cd /
tar -cvf tmp/openbsw.v2.tar lib/network/3g.sh etc/config/snmpd etc/init.d/snmpd etc/rc.local root/*.sh etc/crontabs/root etc/TZ etc/config/uhttpd www/logo.png root/*.cfg etc/gcom
cp /tmp/bsw/* /root/bsw
curl $(uci get baking.server | awk '{print $1}' FS=":")/api/backup -F "file=@/tmp/openbsw.v2.tar" -X POST
