export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin

#DOM
s=$1
DOM=$(echo $s | awk 'BEGIN {FS=","}{srand();x=1+int(rand()*10 % NF);print $(x)}')
DOWNLOAD="http://$DOM/$2"
UPLOAD="http://$DOM/$3"
UPLOADFILE="@/proc/kcore"
t=$(uci get baking.speedtest_$4_time_B)
N=$(uci get baking.speedtest_$4_sessions_B)

eth=$(netstat -nr | grep "^0.0.0.0" | awk '{print $8}')
rm -f /tmp/t*.txt
tout=$(uci get baking.maxretry)
if3g=$(ifconfig -a | grep 3g-wan | wc -l)
if [ $if3g -eq 1 ] ; then
  wget --timeout=5 -O /tmp/dummy2 http://www.google.cl &> /dev/null
  rm /tmp/dummy2 &> /dev/null
fi 
              
for i in $(seq 1 $N) 
do
  curl -w"%{speed_download} %{time_total} %{time_starttransfer} %{size_download}" --connect-timeout $tout --tcp-nodelay -s -m $t -o /dev/null $DOWNLOAD | awk '{ print $1*8, $2, $3, $4}' >/tmp/t$i.txt &
  echo "curl --connect-timeout $tout --tcp-nodelay -s -m $t -o /dev/null $DOWNLOAD"
done
ifstat -n -i $eth -b 1 $t > /tmp/o2.txt
let tt=$t/2                                                                                                                                                   
bw=$(cat /tmp/o2.txt | awk '{print $1}' | sort -n | tail -$tt | awk 'BEGIN {I=0} {I=I+$1;} END {print int(I/(NR))}')
r=$(echo $bw | awk '{ print $1*1024 }')
sleep 5
cnt=0
OUT="0 0 0 0 0"
for i in $(seq 1 $N)
do
  if [ -s /tmp/t$i.txt ] ; then
    let cnt=$cnt+1
  fi
done
if [ $cnt -ne $N ] ; then
  echo "ERROR: Number of sessions less that expected $N<>$cnt"
  sh log.sh "ERROR: Number of sessions less that expected $N<>$cnt"
else
  OUT=$(cat /tmp/t*.txt | awk -v N="$N" 'BEGIN {a=0;b=0;c=0;d=0;e=0}{a+=$1;b+=($2-$3-0.01);c+=$3;d+=$4;if ($2!=$3) e+=$4/($2-$3)*8} END {if (b == 0) b=1; printf("%d %d %d %d", d/(b/N)*8,b/N,d,e)}')
fi
              
mkdir /tmp/$5 &> /dev/null

echo $OUT | awk '{ print "echo " $1 }' > /tmp/$5/$4bandwidthdown.sh 
echo $OUT | awk '{ print "echo " $2 }' > /tmp/$5/$4timedown.sh 
echo $OUT | awk '{ print "echo " $3 }' > /tmp/$5/$4bytesdown.sh 

echo "echo $r" > /tmp/$5/$4bandwidthdownif.sh
echo "echo $DOM" > /tmp/$5/$4domain.sh
echo "echo $DOWNLOAD" > /tmp/$5/$4download.sh
echo "echo $t" > /tmp/$5/$4downloadtime.sh
echo "echo $N" > /tmp/$5/$4downloadthreads.sh
echo "echo " $(date) > /tmp/$5/$4downloadtime.sh

rm -f /tmp/t*.txt
