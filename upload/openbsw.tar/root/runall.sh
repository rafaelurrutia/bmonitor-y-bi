# Baking Software 2012
# VERSION=19.27.2012.v2

clear
cat /etc/banner
echo ">Initializing system"
cat /etc/config/baking | grep ":3362" > /etc/config/bakingbak
SVR1=$(uci get baking.server1)
if [ $? -eq 1 ] ; then
  cp /etc/config/bakingbak  /etc/config/baking
fi
      
cd /root
mkdir /tmp/bsw >& /dev/null
mkdir /root/bsw >& /dev/null
if [ ! -e /tmp/nextrun.txt ] ; then
  > /tmp/nextrun.txt
fi
sh clean.sh
sh httppage.sh
echo address=\"\/router.lan\/$(uci get network.lan.ipaddr)\" > /etc/dnsmasq.conf
/etc/init.d/dnsmasq reload
uci set system.bswkeepalive=0
uci commit 
echo "Starting. Check Internet" >status
sh log.sh "runall.sh: Starting router"
/etc/init.d/uhttpd restart
ps | grep http.sh | grep -v grep | awk '{system("kill -9 " $1)'}
sh http.sh 2>&1 > /dev/null &
sh firewall.sh
echo "BSW System Boot" >status
sh httppage.sh
if [ "$1" != "fast" ] ; then
  echo ">Sleeping 60 seconds to allow login"
  sleep 60
fi
# Check for internet
sh checkinternet.sh
echo "> Syncronizing time"
/usr/sbin/rdate -s nist1.symmetricom.com
sh setup.sh
if [ "$1" != "RESTORE" ] ; then
  sh poweroff.sh &
  dd=$(date +"%s")
  echo $dd > lastboot
fi
if [ ! -e lastboot ] ; then
  dd=$(date +"%s")
  echo $dd > lastboot
fi
sh quote.sh
uci show baking | grep ITEM | awk 'BEGIN {FS="="}{print $1 "="}' | xargs  -n1 uci set &>/dev/null

echo "Starting. Stopping Running Applications" > status
echo ">Stopping Applications"
sh httppage.sh
ps | grep bswloop.sh | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep curl.sh | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep bswcheck.sh | grep -v grep | awk '{system("kill -9 " $1)'}
ps | grep sleep | grep -v grep | awk '{system("kill -9 " $1)'}

uci set baking.start=$(date +"%s")
uci set baking.stop=$(date +"%s")
uci commit

f=$(uci show firewall | grep dest_port=1161 | wc -l)
if [ $f -eq 0 ] ; then
  echo ">Add 1161 to firewall"
  uci add firewall rule              
  uci set firewall.@rule[-1].src=wan
  uci set firewall.@rule[-1].target=ACCEPT
  uci set firewall.@rule[-1].proto=udp
  uci set firewall.@rule[-1].dest_port=1161
  uci commit firewall 
  sh firewall.sh
fi                   
uci set snmpd.@system[0].sysName=$(sh getmac.sh  | awk '{ gsub(":",""); print "BSW" $1}')
uci set system.bswkeepalive=0
uci commit            
echo ">Restarting SNMP"
/etc/init.d/snmpd restart
echo ">Restarting cron"
/etc/init.d/cron restart

rm /etc/config/ntpclient >& /dev/null
killall ntpclient >& /dev/null          

echo "Staring BSW Applications" > status
echo ">Starting BSW Applications"
sh httppage.sh
cp /root/bsw/* /tmp/bsw >& /dev/null
rm /tmp/config.sh >& /dev/null
pc=$(uci get baking.pcontrol)                                                                           
if [ "$pc" == "1" ] ; then                                                                            
  sh pcontrol.sh                                                                                        
fi                                                                                                      
sh bswcheck.sh 2>&1 > /dev/null &
sh bswloop.sh 2>&1 > /dev/null &
echo "Operational" > status
sh log.sh "runall.sh: Completed"
echo ">Initialization Complete"
sh httppage.sh
echo ""

