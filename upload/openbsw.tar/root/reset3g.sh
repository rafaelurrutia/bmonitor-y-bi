sh log.sh "reset3g.sh"
  if3g=$(ifconfig -a | grep 3g-wan | wc -l)
  if [ $if3g -eq 0 ] ; then
    exit
  fi 
  gcom -s /etc/gcom/GPRSdown.gcom
  echo 0 > /sys/devices/platform/ar71xx-ehci/usb1/1-1/authorized
  sleep 5
  echo 1 > /sys/devices/platform/ar71xx-ehci/usb1/1-1/authorized
  sleep 5
  /etc/init.d/network restart     
  sleep 15
  wget --timeout=5 -O /tmp/dummynet http://www.google.cl  >& /dev/null
  rm /tmp/dummynet &> /dev/null
  c=$(fping -t1000 -s -c 2 -r 1 www.yahoo.com 2>&1 | grep "2 ICMP Echo Replies" | wc -l)
  if [ $c -eq 0 ] ; then
    gcom -s /etc/gcom/reset.gcom
    sleep 5
    usb_modeswitch -I -W -H -R -c /etc/usb_modeswitch.d/12d1\:1446
    sleep 15
    usb_modeswitch -I -W -H -R -c /etc/usb_modeswitch.d/12d1\:1446
  fi                                
