# Baking Software
# Initialization script

cd /tmp
echo "Got upgrade signal. Upgrading..." > status
sh /root/httppage.sh
SERVER1=$(uci get baking.server1)
SERVER2=$(uci get baking.server2)

cat /etc/config/baking | grep -v 'ITEM' | awk '{ if (length($0) != 0) print $0}' > /tmp/baking
mv /tmp/baking /etc/config/baking

OK=0                                                       
rsize=$(curl -s --head URL http://$SERVER1/linksys/openbsw.tar | grep "Content-Length" | awk '{print $2}')
echo "Local File Size:$rsize"
wget -q -T5 -O openbsw.tar http://$SERVER1/linksys/openbsw.tar
if [ $? -eq 0 ] ; then           
  if [ -s /tmp/openbsw.tar ] ; then
    lsize=$(ls -al /tmp/openbsw.tar | awk '{print $5}')
    echo "Remote File Size:$lsize"
    if [ $rsize -eq $lsize ] ; then
      echo ">CRC OK"
      OK=1
    fi
  else                                                       
    size=$(curl -s --head URL http://$SERVER2/linksys/openbsw.tar | grep "Content-Length" | awk '{print $2}')
    echo "Local File Size:$rsize"
    wget -q -T5 -O openbsw.tar http://$SERVER2/linksys/openbsw.tar
    if [ $? -eq 0 ] ; then           
      if [ -s /tmp/openbsw.tar ] ; then
        lsize=$(ls -al /tmp/openbsw.tar | awk '{print $5}')
        echo "Remote File Size:$lsize"
        if [ $rsize -eq $lsize ] ; then
          echo ">CRC OK"
          OK=1 
        fi          
      fi               
    fi                    
  fi                      
  if [ $OK -eq 1 ] ; then                           
    cd /
    echo ">UNTAR"
    tar xvf /tmp/openbsw.tar &>/dev/null
    echo ">"
    echo ">SYSCTL"
    sysctl -p  
    echo ">"
    cd /root                                          
    v=$(cat /etc/config/system | grep version | wc -l)
    if [ $v -eq 0 ] ; then            
      uci set system.version="0.0.0.0"
      uci commit system            
    fi                                                  
    uci set system.lastupdate=$(date +"%Y-%m-%d_%H-%M-%S")
    uci commit system         
    /etc/init.d/uhttpd restart
    echo ">RESTORE COMPLETED"
    sh runall.sh "RESTORE"
  else           
    cd /root       
    sleep 5        
    sh restore.sh &
  fi             
else             
  cd /root
  sleep 5
  sh restore.sh &
fi
                                                                                                                                
