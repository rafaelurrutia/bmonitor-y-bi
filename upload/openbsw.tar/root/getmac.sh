x=$(ifconfig -a |grep 3g-wan|wc -l)
y=$(ifconfig -a |grep pppoe-wan|wc -l) 
if [ $x -eq 1 ] || [ $y -eq 1 ] ; then
  echo $(ifconfig br-lan | grep HWaddr | awk '{ print $5}')
else
  eth=$(netstat -nr | grep "^0.0.0.0" | awk '{print $8}')
  if [ "$eth" == "" ] ; then
    eth=$(uci get network.lan.ifname)
  fi
  echo $(ifconfig $eth | grep HWaddr | awk '{ print $5}')
fi

