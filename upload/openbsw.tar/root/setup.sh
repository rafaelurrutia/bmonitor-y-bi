export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/tmp/bin:/tmp/sbin:/tmp/usr/bin:/tmp/usr/sbin
export LD_LIBRARY_PATH=/tmp/usr/lib:/tmp/lib

echo ">Loading packages"
echo "Loading packages" > status

opkg update
f=$(type curl | grep " is " | wc -l)
if [ $f -eq 0 ] ; then
  opkg install curl
fi
f=$(type ifstat | grep " is " | wc -l )
if [ $f -eq 0 ] ; then
  opkg install ifstat
fi
f=$(type tcpdump | grep " is " | wc -l )
if [ $f -eq 0 ] ; then
  opkg install tcpdump
fi
f=$(type snmpd | grep " is " | wc -l )
if [ $f -eq 0 ] ; then
  opkg install snmpd
fi
#f=$(opkg list-installed | grep "^iptables-mod-filter" | wc -l)
#if [ $f -eq 0 ] ; then
#  echo opkg install iptables-mod-filter
#fi
f=$(type netcat | grep " is " | wc -l )
if [ $f -eq 0 ] ; then
  opkg install netcat
fi
f=$(type dig | grep " is " | wc -l )
if [ $f -eq 0 ] ; then
  opkg install bind-dig
fi
f=$(type fping | grep " is " | wc -l )
if [ $f -eq 0 ] ; then
  opkg install fping
fi
f=$(type nohup | grep "is" | wc -l)
if [ $f -eq 0 ] ; then
  opkg install coreutils-nohup
fi
